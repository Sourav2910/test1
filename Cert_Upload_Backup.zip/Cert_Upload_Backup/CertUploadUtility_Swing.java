package amaeriprise.DataPower.Cert_Upload_Backup;

import java.awt.EventQueue;
import java.awt.TextField;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.io.File;

import javax.swing.JFrame;
import javax.swing.JPanel;
import javax.swing.border.EmptyBorder;
import javax.swing.JLabel;
import javax.swing.JOptionPane;
import javax.swing.ButtonGroup;
import javax.swing.JButton;
import javax.swing.JComboBox;
import javax.swing.JFileChooser;
import javax.swing.JRadioButton;
import javax.swing.JPasswordField;
import javax.swing.JTextArea;
import javax.swing.JSeparator;
import java.awt.Color;
import java.awt.Font;

public class CertUploadUtility_Swing extends JFrame implements ActionListener {
	
	private JFileChooser fileChooser;
	public JPanel contentPane;
	public JPasswordField passwordField;
	
	public JTextArea ssoID,certificateNameText,cerLocationText;
	
	public JButton btnImport,btnValidate,btnBrowse,btncertBackup,btnValidateCertDetails; 
	public ButtonGroup serviceType,dpEnvironment,tier,boxType;
	
	JComboBox<String> comboLanguage = new JComboBox<String>();
	
	TextField text = new TextField(20);
    private int numClicks = 0;

	/**
	 * Launch the application.
	 * @return 
	 */
    
	public static void main(String[] args) {
		EventQueue.invokeLater(new Runnable() {
			public void run() {
				try {
					CertUploadUtility_Swing frame = new CertUploadUtility_Swing();
					frame.setVisible(true);
				} catch (Exception e) {
					e.printStackTrace();
				}
			}
		});
	}

	/**
	 * Create the frame.
	 */
	public CertUploadUtility_Swing() {
		setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		setBounds(100, 100, 700, 700);
		contentPane = new JPanel();
		contentPane.setBorder(new EmptyBorder(5, 5, 5, 5));
		setContentPane(contentPane);
		contentPane.setLayout(null);
		
		JLabel lblNewLabel = new JLabel("Welcome to Data Power Cert Upload/Backup Utility");
		lblNewLabel.setFont(new Font("Times New Roman", Font.BOLD, 14));
		lblNewLabel.setForeground(new Color(72, 61, 139));
		lblNewLabel.setBounds(128, 11, 556, 31);
		contentPane.add(lblNewLabel);
		
		JLabel lblNewLabel_1 = new JLabel("SSO ID");
		lblNewLabel_1.setBounds(37, 62, 79, 20);
		contentPane.add(lblNewLabel_1);
		
		ssoID = new JTextArea();
		ssoID.setBounds(164, 60, 191, 22);
		contentPane.add(ssoID);
		
		JLabel lblNewLabel_2 = new JLabel("Password");
		lblNewLabel_2.setBounds(37, 93, 79, 20);
		contentPane.add(lblNewLabel_2);
		
		passwordField = new JPasswordField();
		passwordField.setBounds(164, 93, 191, 20);
		contentPane.add(passwordField);
		
		
		JLabel lblNewLabel_3 = new JLabel("DP Env");
		lblNewLabel_3.setBounds(37, 124, 46, 14); 
		contentPane.add(lblNewLabel_3);
		
		JRadioButton dpE1 = new JRadioButton("E1");
		dpE1.setBounds(164, 120, 40, 23);
		dpE1.setSelected(true);
		dpE1.setActionCommand("E1");
		contentPane.add(dpE1);
		
		JRadioButton dpE2 = new JRadioButton("E2");
		dpE2.setBounds(253, 120, 40, 23);
		dpE2.setSelected(true);
		/*dpE2.setEnabled(false);*/
		dpE2.setActionCommand("E2");
		contentPane.add(dpE2);
		
		JRadioButton dpE3 = new JRadioButton("E3");
		dpE3.setBounds(315, 120, 40, 23);
		dpE3.setSelected(false);
		dpE3.setEnabled(false);
		dpE3.setActionCommand("E3");
		contentPane.add(dpE3);
		
		dpEnvironment = new ButtonGroup();
		dpEnvironment.add(dpE1);
		dpEnvironment.add(dpE2);
		dpEnvironment.add(dpE3);
		
		JRadioButton appTier = new JRadioButton("AppTier");
		appTier.setBounds(164, 145, 70, 23);
		appTier.setSelected(true);
		appTier.setActionCommand("AppTier");
		contentPane.add(appTier);
		
		JRadioButton webTier = new JRadioButton("WebTier");
		webTier.setBounds(254, 146, 101, 23);
		webTier.setSelected(true);
		webTier.setActionCommand("WebTier");
		contentPane.add(webTier);
		
		tier = new ButtonGroup();
		tier.add(appTier);
		tier.add(webTier);
		
		
		JLabel lblboxtyp = new JLabel("boxType");
		contentPane.add(lblboxtyp);
		
		JRadioButton primary = new JRadioButton("Primary");
		primary.setBounds(164, 171, 70, 23);
		primary.setSelected(true);
		primary.setActionCommand("Primary");
		contentPane.add(primary);
		
		JRadioButton secondary = new JRadioButton("Secondary");
		secondary.setBounds(254, 172, 110, 23);
		secondary.setSelected(true);
		secondary.setActionCommand("Secondary");
		contentPane.add(secondary);
		
		boxType = new ButtonGroup();
		boxType.add(primary);
		boxType.add(secondary);
		
		

		JLabel lblDomain = new JLabel("Domain");
		lblDomain.setBounds(37, 205, 79, 14);
		contentPane.add(lblDomain);
		
				
		comboLanguage.addItem("E0Domain");
		comboLanguage.addItem("E1Domain");
		comboLanguage.addItem("DudeDomain");
		comboLanguage.addItem("E0WebDomain");
		comboLanguage.addItem("E1WebDomain");
		comboLanguage.addItem("WebDomain");
		
		comboLanguage.setEditable(false);
		comboLanguage.setBounds(164, 201, 150, 23);
		
		contentPane.add(comboLanguage);
		
		JLabel certificateName = new JLabel("Cert Name:");
		certificateName.setBounds(37, 294, 103, 17);
		contentPane.add(certificateName);
		
		certificateNameText = new JTextArea();
		
		certificateNameText.setEditable(false);
		certificateNameText.setBounds(161, 290, 203, 22);
		contentPane.add(certificateNameText);
		
		
		/*btnBrowse = new JButton("Browse");
		 btnValidate.setBounds(250, 270, 79, 14);
		 contentPane.add(btnBrowse);*/
		
		/*btnBrowse = new JButton("Browse");
		btnBrowse.setBounds(369, 271, 79, 14);
		 contentPane.add(btnBrowse);*/
		
		
		btnBrowse = new JButton("Browse");
		btnBrowse.setBounds(517, 258, 89, 23);
		 contentPane.add(btnBrowse);
		 
		 
		 
		
		
		JLabel cerLocation = new JLabel("Cert Location:");
		cerLocation.setBounds(37, 263, 117, 20); 
		contentPane.add(cerLocation);
		
		cerLocationText = new JTextArea();
		cerLocationText.setBounds(164, 257, 332, 22);
		contentPane.add(cerLocationText);
		
		
		 btnValidate = new JButton("Validate Cert Upload");
		 btnValidate.setBounds(164, 323, 150, 23);
		 contentPane.add(btnValidate);
		 
			btnImport = new JButton("Upload Certificate");
			btnImport.setBounds(327, 323, 152, 23);
			contentPane.add(btnImport);
			
			btnImport.setEnabled(false);
			
			
			
			
		
		
		JLabel lblTier = new JLabel("Tier");
		lblTier.setBounds(37, 149, 46, 14);
		contentPane.add(lblTier);
		
		JLabel lblBoxtype = new JLabel("BoxType");
		lblBoxtype.setBounds(37, 175, 79, 14);
		contentPane.add(lblBoxtype);
		
		JLabel cryptoCert = new JLabel("CryptoCert Object:");
		cryptoCert.setBounds(37, 563, 117, 20);
		contentPane.add(cryptoCert);
		
		JTextArea cryptoCerttext = new JTextArea();
		cryptoCerttext.setBounds(164, 561, 227, 22);
		contentPane.add(cryptoCerttext);
		
		
		
		JButton btnCryptoCert = new JButton("Refresh CryptoCert");
		btnCryptoCert.setBounds(337, 603, 142, 23);
		contentPane.add(btnCryptoCert);
		
		btnCryptoCert.setEnabled(false);
		
	
		btnCryptoCert.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				 
					String loginID = ssoID.getText().trim();
					String password = passwordField.getText().trim();
				/*	String serType= serviceType.getSelection().getActionCommand();*/
					String dpEnv = dpEnvironment.getSelection().getActionCommand();
					String dpTier = tier.getSelection().getActionCommand();
					String boxTyp = boxType.getSelection().getActionCommand();
					String domain = (String) comboLanguage.getSelectedItem();
					
					String cerName = certificateNameText.getText().trim();
					
					
					String cerLocation = cerLocationText.getText().trim();
					
					
					String cryptoCertObj = cryptoCerttext.getText().trim();
					
					
					System.out.println(domain+cerName+cerLocation);
					
					String CertObjectNotUpMsg = "certificate object"+" '"+cryptoCertObj+"' "+"is not up" ;
					System.out.println(CertObjectNotUpMsg);
					DP_Utility_Cert dp_Utility = new DP_Utility_Cert();
					try {
						String result = dp_Utility.refreshCertObject(loginID,password,dpEnv,dpTier,boxTyp,domain,cerName,cerLocation,cryptoCertObj);
						
						if(result=="All Good")
						{
							JOptionPane.showMessageDialog(btnCryptoCert, "Certificate Object: " + cryptoCertObj +  " Refreshed","title of dialog",2);
							btnCryptoCert.setEnabled(false);
						}
						
						else if (result=="Configuration not found") {
							JOptionPane.showMessageDialog(btnImport, "Configuration not found, Please check details","title of dialog",2);
							btnCryptoCert.setEnabled(false);
						}
						else{
							JOptionPane.showMessageDialog(btnImport, "Authentication failure, Please check details","title of dialog",2);
							btnCryptoCert.setEnabled(false);
							
						}
						
						
					
						/*btnImport.setEnabled(false);
						btnValidate.setEnabled(true);*/
						
					} catch (Exception e1) {
						// TODO Auto-generated catch block
				/*		btnImport.setEnabled(false);
						btnValidate.setEnabled(true);*/
						e1.printStackTrace();
						JOptionPane.showMessageDialog(btnCryptoCert, e1,"Error",2);
					}
				 
			 }
		
		});
		
		
		
		
		//  Certificate Upload
		
	/*	JLabel CCUpload = new JLabel("CryptoCert Upload:");
		CCUpload.setBounds(37, 600, 117, 20);
		contentPane.add(CCUpload);
		
		JTextArea CCUploadtext = new JTextArea();
		CCUploadtext.setBounds(164, 598, 227, 22);
		contentPane.add(CCUploadtext);
		
		JButton btnCryptoCertUpload = new JButton("Create CryptoCert");
		btnCryptoCertUpload.setBounds(420, 599, 159, 23);
		contentPane.add(btnCryptoCertUpload);*/
		
		
			//CertBackup
		
		JLabel certObjectName = new JLabel("Cert Object Name:");
		certObjectName.setBounds(37, 399, 117, 20);
		contentPane.add(certObjectName);
		
		JTextArea certObjectNameText = new JTextArea();
		certObjectNameText.setBounds(164, 397, 227, 22);
		contentPane.add(certObjectNameText);
		
		
		JButton btncertBackup = new JButton("Create Cert Backup");
		btncertBackup.setBounds(330, 498, 150, 23);
		contentPane.add(btncertBackup);
	
		JLabel CertSaveDirectory = new JLabel("Cert Save Directory:");
		CertSaveDirectory.setBounds(37, 430, 117, 20);
		contentPane.add(CertSaveDirectory);
		
		
		JTextArea CertsaveDirText = new JTextArea();
		
		CertsaveDirText.setEditable(false);
		CertsaveDirText.setBounds(164, 430, 332, 22);
		contentPane.add(CertsaveDirText);
		
		
		JButton CertsavePth = new JButton("Browse");
		CertsavePth.setBounds(506, 431, 89, 23);
		contentPane.add(CertsavePth);
		
		
		CertsavePth.addActionListener(new ActionListener()
		{
			 public void actionPerformed(ActionEvent e){
				 
				 
				 
				 JFileChooser f = new JFileChooser();
			        f.setFileSelectionMode(JFileChooser.DIRECTORIES_ONLY); 
			        f.showSaveDialog(null);
			        
			        
			        CertsaveDirText.setText(f.getSelectedFile().getAbsolutePath());
					//certificateNameText.setText(CertLocation.substring(CertLocation.lastIndexOf("\\")+1));
					
			        System.out.println(f.getCurrentDirectory());
			        System.out.println(f.getSelectedFile());
				 
				 
				 
			 }
			
		});
		
		
		
		
		JLabel CertSaveas = new JLabel("Cert Save-As:");
		CertSaveas.setBounds(37, 461, 117, 20);
		contentPane.add(CertSaveas);
		
		JTextArea CertSaveasText = new JTextArea();
		CertSaveasText.setBounds(164, 465, 227, 22);
		contentPane.add(CertSaveasText);
		
		
		JButton btnValidateCertDetails = new JButton("Validate Cert Backup");
		btnValidateCertDetails.setBounds(164, 498, 150, 23);
		contentPane.add(btnValidateCertDetails);
		btncertBackup.setEnabled(false);
		
		btnValidateCertDetails.addActionListener(new ActionListener()
		{
		    public void actionPerformed(ActionEvent e)
		    {
		        // Create a method named "createFrame()", and set up an new frame there
		    	
		    	Boolean loginIDFlag = true;
		    	Boolean passwordFlag = true;
		    	Boolean dpEnvFlag = true;
		    	Boolean dpTierFlag = true;
		    	Boolean boxTypFlag = true;
		    	Boolean domainFlag = true;
		    	Boolean cerSaveDirtxtFlag = true;
		    	Boolean cerSaveAstxtFlag = true;
		    	Boolean certObjectNameTxtFlag = true;
		    	
		    	
		    	String loginID;
		    	String password;
		    	String dpEnv ;
		    	String dpTier ;
		    	String boxTyp;
		    	String domain;
		    	String cerSaveDirtxt;
		    	String cerSaveAstxt;
		    	String certObjectNameTxt;
		    	
		    	
		  //  	String loginID = ssoID.getText().trim();
			//	String password = passwordField.getText().trim();
			//	String dpEnv = dpEnvironment.getSelection().getActionCommand();
			//	String dpTier = tier.getSelection().getActionCommand();
			//	String boxTyp = boxType.getSelection().getActionCommand();
			//	String domain = (String) comboLanguage.getSelectedItem();
				
			//	String cerSaveDirtxt = CertsaveDirText.getText().trim();
			//	String cerSaveAstxt = CertSaveasText.getText().trim();
				//String certObjectNameTxt= certObjectNameText.getText().trim();
				
				
				if (ssoID.getText().trim().isEmpty())
				{
					loginID = "Please enter your SSO ID !!";
					loginIDFlag = false;
					System.out.println(loginID);
					
				}
				else {
					 loginID = ssoID.getText().trim();
				}
				
				
				if (passwordField.getText().trim().isEmpty()) {
					
					password= "Please enter your password!!";
					passwordFlag = false;
				}
				else {
					password = "********";
				}
				
				
				if (dpEnvironment.getSelection().getActionCommand().isEmpty())
				{
					dpEnv = "Please select DP env";
					dpEnvFlag = false;
					System.out.println(dpEnvFlag);
					
				}
				else {
					 dpEnv = dpEnvironment.getSelection().getActionCommand();
				}
				
				
				if (tier.getSelection().getActionCommand().isEmpty())
				{
					dpTier = "Please select DP Tier";
					dpTierFlag = false;
					System.out.println(dpEnvFlag);
					
				}
				else {
					dpTier = tier.getSelection().getActionCommand();
				}
				
				
				if (boxType.getSelection().getActionCommand().isEmpty())
				{
					boxTyp = "Please select DP box";
					boxTypFlag = false;
					System.out.println(boxTypFlag);
					
				}
				else {
					boxTyp = boxType.getSelection().getActionCommand();
				}
				
				
				if (comboLanguage.getSelectedItem().toString().isEmpty())
				{
					domain = "Please select DP Domain";
					domainFlag = false;
					System.out.println(domainFlag);
					
				}
				else {
					domain = (String) comboLanguage.getSelectedItem();
				}
				
				
				if (CertsaveDirText.getText().trim().isEmpty())
				{
					cerSaveDirtxt = "Please enter Cert Object Name!";
					cerSaveDirtxtFlag = false;
					System.out.println(cerSaveDirtxtFlag);
					
				}
				else {
					cerSaveDirtxt = CertsaveDirText.getText().trim();
				}
				
				if (CertSaveasText.getText().trim().isEmpty())
				{
					cerSaveAstxt = "Please Enter Directory!";
					cerSaveAstxtFlag = false;
					System.out.println(cerSaveAstxtFlag);
					
				}
				else {
					cerSaveAstxt = CertSaveasText.getText().trim();
				}
				
				
				if (CertsaveDirText.getText().trim().isEmpty())
				{
					certObjectNameTxt = "Please enter Save As!";
					certObjectNameTxtFlag = false;
					System.out.println(certObjectNameTxtFlag);
					
				}
				else {
					certObjectNameTxt= certObjectNameText.getText().trim();
				}
				
				
				
				
				
				
				
		    	
				String Validate = "loginID :     " + loginID + "\n"
						+"password :    " + password + "\n"
						+"dpEnv :     " + dpEnv + "\n"
						+"dpTier :    " + dpTier + "\n"
						+"boxTyp :      " + boxTyp + "\n"
						+"domain :     " + domain + "\n"
						+"CertObjectName :     " + certObjectNameTxt + "\n"
						+"cerSaveLocation :      " + cerSaveDirtxt + "\n"
						+"certificateName :      " + cerSaveAstxt + "\n";
		
				int input = JOptionPane.showOptionDialog(btnValidate, Validate, "Validate", JOptionPane.OK_CANCEL_OPTION, JOptionPane.INFORMATION_MESSAGE, null, null, null);

				if(input == JOptionPane.OK_OPTION && loginIDFlag && passwordFlag && dpEnvFlag && dpTierFlag && boxTypFlag &&  domainFlag && cerSaveAstxtFlag
						&&cerSaveAstxtFlag && certObjectNameTxtFlag)
				{
					btncertBackup.setEnabled(true);
				}
				
				// 				if(input == JOptionPane.CANCEL_OPTION || input == JOptionPane.CLOSED_OPTION)
				else
				{
					btncertBackup.setEnabled(false);
					
				}
				
		    }
		});
		
		
		JButton btnValidateCertObject = new JButton("Validate Cert Object");
		btnValidateCertObject.setBounds(164, 603, 150, 23);
		contentPane.add(btnValidateCertObject);
		
		JSeparator separator = new JSeparator();
		separator.setBounds(37, 230, 167, 0);
		contentPane.add(separator);
		
		JSeparator separator_1 = new JSeparator();
		separator_1.setBounds(19, 230, 599, 143);
		contentPane.add(separator_1);
		
		JLabel lblCertUpload = new JLabel("Cert Upload");
		lblCertUpload.setFont(new Font("Times New Roman", Font.BOLD, 12));
		lblCertUpload.setForeground(Color.BLUE);
		lblCertUpload.setBounds(269, 235, 122, 20);
		contentPane.add(lblCertUpload);
		
		JLabel lblNewLabel_4 = new JLabel("Cert backup");
		lblNewLabel_4.setFont(new Font("Times New Roman", Font.BOLD, 13));
		lblNewLabel_4.setForeground(Color.BLUE);
		lblNewLabel_4.setBounds(269, 375, 87, 20);
		contentPane.add(lblNewLabel_4);
		
		JSeparator separator_2 = new JSeparator();
		separator_2.setBounds(19, 371, 599, 150);
		contentPane.add(separator_2);
		
		JLabel lblCertRefresh = new JLabel("Cert Refresh");
		lblCertRefresh.setFont(new Font("Times New Roman", Font.BOLD, 12));
		lblCertRefresh.setForeground(Color.BLUE);
		lblCertRefresh.setBounds(269, 543, 87, 14);
		contentPane.add(lblCertRefresh);
		
		JSeparator separator_3 = new JSeparator();
		separator_3.setBounds(33, 532, 585, 130);
		contentPane.add(separator_3);
		
		btnValidateCertObject.addActionListener(new ActionListener()
		{
		    public void actionPerformed(ActionEvent e)
		    {
		        // Create a method named "createFrame()", and set up an new frame there
		    	
		    	Boolean loginIDFlag = true;
		    	Boolean passwordFlag = true;
		    	Boolean dpEnvFlag = true;
		    	Boolean dpTierFlag = true;
		    	Boolean boxTypFlag = true;
		    	Boolean domainFlag = true;
		    	Boolean cryptoCerttxtFlag = true;
		    	
		    	
		    	
		    	String loginID;
		    	String password;
		    	String dpEnv ;
		    	String dpTier ;
		    	String boxTyp;
		    	String domain;
		    	
		    	
		    	String cryptoCerttxt;
		    	
		    	
		    	
		    	
		  //  	String loginID = ssoID.getText().trim();
			//	String password = passwordField.getText().trim();
			//	String dpEnv = dpEnvironment.getSelection().getActionCommand();
			//	String dpTier = tier.getSelection().getActionCommand();
			//	String boxTyp = boxType.getSelection().getActionCommand();
			//	String domain = (String) comboLanguage.getSelectedItem();
				
			//	String cerSaveDirtxt = CertsaveDirText.getText().trim();
			//	String cerSaveAstxt = CertSaveasText.getText().trim();
				//String certObjectNameTxt= certObjectNameText.getText().trim();
				
				
				if (ssoID.getText().trim().isEmpty())
				{
					loginID = "Please enter your SSO ID !!";
					loginIDFlag = false;
					System.out.println(loginID);
					
				}
				else {
					 loginID = ssoID.getText().trim();
				}
				
				
				if (passwordField.getText().trim().isEmpty()) {
					
					password= "Please enter your password!!";
					passwordFlag = false;
				}
				else {
					password = "********";
				}
				
				
				if (dpEnvironment.getSelection().getActionCommand().isEmpty())
				{
					dpEnv = "Please select DP env";
					dpEnvFlag = false;
					System.out.println(dpEnvFlag);
					
				}
				else {
					 dpEnv = dpEnvironment.getSelection().getActionCommand();
				}
				
				
				if (tier.getSelection().getActionCommand().isEmpty())
				{
					dpTier = "Please select DP Tier";
					dpTierFlag = false;
					System.out.println(dpEnvFlag);
					
				}
				else {
					dpTier = tier.getSelection().getActionCommand();
				}
				
				
				if (boxType.getSelection().getActionCommand().isEmpty())
				{
					boxTyp = "Please select DP box";
					boxTypFlag = false;
					System.out.println(boxTypFlag);
					
				}
				else {
					boxTyp = boxType.getSelection().getActionCommand();
				}
				
				
				if (comboLanguage.getSelectedItem().toString().isEmpty())
				{
					domain = "Please select DP Domain";
					domainFlag = false;
					System.out.println(domainFlag);
					
				}
				else {
					domain = (String) comboLanguage.getSelectedItem();
				}
				
				
				if (cryptoCerttext.getText().trim().isEmpty())
				{
					cryptoCerttxt = "Please enter Cert Object Name!";
					cryptoCerttxtFlag = false;
					System.out.println(cryptoCerttxtFlag);
					
				}
				else {
					cryptoCerttxt = cryptoCerttext.getText().trim();
				}
				
		    	
				String Validate = "loginID :     " + loginID + "\n"
						+"password :    " + password + "\n"
						+"dpEnv :     " + dpEnv + "\n"
						+"dpTier :    " + dpTier + "\n"
						+"boxTyp :      " + boxTyp + "\n"
						+"domain :     " + domain + "\n"
						+"CertObjectName :     " + cryptoCerttxt + "\n";
		
				int input = JOptionPane.showOptionDialog(btnValidate, Validate, "Validate", JOptionPane.OK_CANCEL_OPTION, JOptionPane.INFORMATION_MESSAGE, null, null, null);

				if(input == JOptionPane.OK_OPTION && loginIDFlag && passwordFlag && dpEnvFlag && dpTierFlag && boxTypFlag &&  domainFlag && cryptoCerttxtFlag)
				{
					btnCryptoCert.setEnabled(true);
				}
				
				// 				if(input == JOptionPane.CANCEL_OPTION || input == JOptionPane.CLOSED_OPTION)
				else
				{
					btnCryptoCert.setEnabled(false);
					
				}
				
		    }
		});
		
		
		
		
		
		
		
		
		
		// Cert upload Action
	
		
	/*	btnCryptoCertUpload.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				 
					String loginID = ssoID.getText().trim();
					String password = passwordField.getText().trim();
					String serType= serviceType.getSelection().getActionCommand();
					String dpEnv = dpEnvironment.getSelection().getActionCommand();
					String dpTier = tier.getSelection().getActionCommand();
					String boxTyp = boxType.getSelection().getActionCommand();
					String domain = (String) comboLanguage.getSelectedItem();
					
					String cerName = certificateNameText.getText().trim();

					String cerLocation = cerLocationText.getText().trim();
					
					String cryptoCertObj = cryptoCerttext.getText().trim();
					
					String CCUpload = CCUploadtext.getText().trim();
					
					System.out.println(CCUploadtext.getText().trim());
					
					DP_Utility_Cert dp_Utility = new DP_Utility_Cert();
					try {
					String result =	dp_Utility.CryptoCertObjectUpload(loginID,password,dpEnv,dpTier,boxTyp,domain,cerName,cerLocation,cryptoCertObj,CCUpload);
						
						
						if(result=="Authentication failure")
						{
							JOptionPane.showOptionDialog( null, "Authentication failure, please check your Input", "Error", JOptionPane.OK_CANCEL_OPTION, JOptionPane.INFORMATION_MESSAGE, null, null, 3);
							btncertBackup.setEnabled(false);
							btnValidateCertDetails.setEnabled(true);
						}
						else{
							JOptionPane.showMessageDialog(btnImport, "Certificate:    " + CCUpload +  "   Imported","title of dialog",2);
							btncertBackup.setEnabled(false);
							btnValidateCertDetails.setEnabled(true);
						}
						
						
						
						
					} catch (Exception e1) {
						// TODO Auto-generated catch block
						btnValidateCertDetails.setEnabled(false);
						btncertBackup.setEnabled(true);
						e1.printStackTrace();
						JOptionPane.showMessageDialog(btnImport, e1,"Error",2);
					}
				 
			 }
		
		});
		
		*/
		
		
		
		/*JFileChooser f = new JFileChooser();
        f.setFileSelectionMode(JFileChooser.DIRECTORIES_ONLY); 
        f.showSaveDialog(null);

        System.out.println(f.getCurrentDirectory());
        System.out.println(f.getSelectedFile());*/
		
		
		btnBrowse.addActionListener(new ActionListener()
		{
			 public void actionPerformed(ActionEvent e){
				 
				 
				 fileChooser = new JFileChooser();
				
				 
				 	
				 fileChooser.setDialogTitle("Select Certificate");
				 
					
				/* FileNameExtensionFilter filter = new FileNameExtensionFilter(".cer", "certificates");
				 fileChooser.addChoosableFileFilter(filter);*/

				 int returnVal = fileChooser.showOpenDialog(null);
				 
				    if (returnVal == JFileChooser.APPROVE_OPTION) {
				    	
				        File file = fileChooser.getSelectedFile();

				        // What to do with the file, e.g. display it in a TextArea
				        
				        String CertLocation = file.getAbsolutePath();
				       
				        System.out.println(CertLocation.substring(CertLocation.lastIndexOf("\\")+1));
				        cerLocationText.setText(CertLocation);
						certificateNameText.setText(CertLocation.substring(CertLocation.lastIndexOf("\\")+1));
						
				    } else {
				        System.out.println("File access cancelled by user.");
				    }
				 
			 }
			
		});
		
		
		
		
		btnImport.addActionListener(new ActionListener()
		{
			 public void actionPerformed(ActionEvent e){
				 
				 String loginID = ssoID.getText().trim();
					String password = passwordField.getText().trim();
				/*	String serType= serviceType.getSelection().getActionCommand();*/
					String dpEnv = dpEnvironment.getSelection().getActionCommand();
					String dpTier = tier.getSelection().getActionCommand();
					String boxTyp = boxType.getSelection().getActionCommand();
					String domain = (String) comboLanguage.getSelectedItem();
					
					String cerName = certificateNameText.getText().trim();
					
					
					String cerLocation = cerLocationText.getText().trim();
					
					
					System.out.println(domain+cerName+cerLocation);
					
					DP_Utility_Cert dp_Utility = new DP_Utility_Cert();
					try {
					String result =	dp_Utility.uploadCert(loginID,password,dpEnv,dpTier,boxTyp,domain,cerName,cerLocation);
					
					if(result=="All Good")
					{
						JOptionPane.showMessageDialog(btnImport, "Certificate:    " + cerName +  "   Imported","title of dialog",2);
						btnImport.setEnabled(false);
						btnValidate.setEnabled(true);
						
					}	
					else{
						JOptionPane.showMessageDialog(btnImport, "Authentication failure, Please check details","title of dialog",2);
						btnImport.setEnabled(false);
						btnValidate.setEnabled(true);
						
					}
					
					} catch (Exception e1) {
						// TODO Auto-generated catch block
						btnImport.setEnabled(false);
						btnValidate.setEnabled(true);
						e1.printStackTrace();
						JOptionPane.showMessageDialog(btnImport, e1,"Error",2);
					}
				 
			 }
			
		});
	
		
		
		btnValidate.addActionListener(new ActionListener()
		{
		    public void actionPerformed(ActionEvent e)
		    {
		        // Create a method named "createFrame()", and set up an new frame there
		    	
		    	
		    	/*String loginID = ssoID.getText().trim();
				String password = passwordField.getText().trim();
				String dpEnv = dpEnvironment.getSelection().getActionCommand();
				String dpTier = tier.getSelection().getActionCommand();
				String boxTyp = boxType.getSelection().getActionCommand();
				String domain = (String) comboLanguage.getSelectedItem();
				
				String certificateNametxt = certificateNameText.getText().trim();
				String cerLocationtxt = cerLocationText.getText().trim();*/
				
		    	
		    	String loginID;
		    	String password;
		    	String dpEnv;
		    	String dpTier;   
		    	String boxTyp;   
		    	String domain;  
		    	String certificateNametxt;
		    	String cerLocationtxt;

				
				Boolean loginIDFlag = true;
		    	Boolean passwordFlag = true;
		    	Boolean dpEnvFlag = true;
		    	Boolean dpTierFlag = true;
		    	Boolean boxTypFlag = true;
		    	Boolean domainFlag = true;
		    	
		    	Boolean certificateNametxtFlag = true;
		    	Boolean cerLocationtxtFlag = true;
		    	
		    	
		    	
		    	
				
				
				if (ssoID.getText().trim().isEmpty())
				{
					loginID = "Please enter your SSO ID !!";
					loginIDFlag = false;
					System.out.println(loginID);
					
				}
				else {
					 loginID = ssoID.getText().trim();
				}
				
				
				if (passwordField.getText().trim().isEmpty()) {
					
					password= "Please enter your password!!";
					passwordFlag = false;
				}
				else {
					password = "********";
				}
				
				
				if (dpEnvironment.getSelection().getActionCommand().isEmpty())
				{
					dpEnv = "Please select DP env";
					dpEnvFlag = false;
					System.out.println(dpEnvFlag);
					
				}
				else {
					 dpEnv = dpEnvironment.getSelection().getActionCommand();
				}
				
				
				if (tier.getSelection().getActionCommand().isEmpty())
				{
					dpTier = "Please select DP Tier";
					dpTierFlag = false;
					System.out.println(dpEnvFlag);
					
				}
				else {
					dpTier = tier.getSelection().getActionCommand();
				}
				
				
				if (boxType.getSelection().getActionCommand().isEmpty())
				{
					boxTyp = "Please select DP box";
					boxTypFlag = false;
					System.out.println(boxTypFlag);
					
				}
				else {
					boxTyp = boxType.getSelection().getActionCommand();
				}
				
				
				if (comboLanguage.getSelectedItem().toString().isEmpty())
				{
					domain = "Please select DP Domain";
					domainFlag = false;
					System.out.println(domainFlag);
					
				}
				else {
					domain = (String) comboLanguage.getSelectedItem();
				}
				
				
				if (certificateNameText.getText().trim().isEmpty())
				{
					certificateNametxt = "Please enter Cert Name!!";
					certificateNametxtFlag = false;
					System.out.println(certificateNametxtFlag);
					
				}
				else {
					certificateNametxt = certificateNameText.getText().trim();
				}
				
				if (cerLocationText.getText().trim().isEmpty())
				{
					cerLocationtxt = "Please Enter Directory!";
					cerLocationtxtFlag = false;
					System.out.println(cerLocationtxtFlag);
					
				}
				else {
					cerLocationtxt = cerLocationText.getText().trim();
				}
				
				
				
		    	
				String Validate = "loginID:      " + loginID + "\n"
						+"password:      " + password + "\n"
						+"dpEnv:          " + dpEnv + "\n"
						+"dpTier:       " + dpTier + "\n"
						+"boxTyp:         " + boxTyp + "\n"
						+"domain:   " + domain + "\n"
						+"certificateNametxt:        " + certificateNametxt + "\n"
						+"cerLocation:     " + cerLocationtxt + "\n"
						;
		
				int input = JOptionPane.showOptionDialog(btnValidate, Validate, "Validate", JOptionPane.OK_CANCEL_OPTION, JOptionPane.INFORMATION_MESSAGE, null, null, null);
				

				if(input == JOptionPane.OK_OPTION && loginIDFlag && passwordFlag && dpEnvFlag && dpTierFlag && boxTypFlag && domainFlag && certificateNametxtFlag && cerLocationtxtFlag  )
				{
					btnImport.setEnabled(true);
				}
				
				//if(input == JOptionPane.CANCEL_OPTION || input == JOptionPane.CLOSED_OPTION)
				else
				{
					btnImport.setEnabled(false);
				}
				
				
		     //    validateInformation(loginID,password,dpEnv,dpTier,dpTier,domain);
		    }
		});
	
		btncertBackup.addActionListener(new ActionListener()
		{
		    public void actionPerformed(ActionEvent e)
		    {
		        // Create a method named "createFrame()", and set up an new frame there
		    	
		    	
		    	String loginID = ssoID.getText().trim();
				String password = passwordField.getText().trim();
				String dpEnv = dpEnvironment.getSelection().getActionCommand();
				String dpTier = tier.getSelection().getActionCommand();
				String boxTyp = boxType.getSelection().getActionCommand();
				String domain = (String) comboLanguage.getSelectedItem();
				/*String certificateNametxt = certificateNameText.getText().trim();
				*/String cerLocationtxt = cerLocationText.getText().trim();
				
				String cerSaveDirtxt = CertsaveDirText.getText().trim();
				String cerSaveAstxt = CertSaveasText.getText().trim();
				
				
				String certObjectTxt= certObjectNameText.getText().trim();
				
		    	
				DP_Utility_Cert dp_Utility = new DP_Utility_Cert();
				try {
					String result = dp_Utility.CertBackup(loginID,password,dpEnv,dpTier,boxTyp,domain,certObjectTxt,cerSaveDirtxt,cerSaveAstxt);
					
					if(result=="Authentication failure")
					{
						JOptionPane.showOptionDialog( null, "Authentication failure, please check your Input", "Error", JOptionPane.OK_CANCEL_OPTION, JOptionPane.INFORMATION_MESSAGE, null, null, 3);
						btncertBackup.setEnabled(false);
						btnValidateCertDetails.setEnabled(true);
					}
					

					else if(result=="Cannot read the specified file")
					{
						JOptionPane.showOptionDialog( null, "Cannot read the specified file", "Error", JOptionPane.OK_CANCEL_OPTION, JOptionPane.INFORMATION_MESSAGE, null, null, 3);
						btncertBackup.setEnabled(false);
						btnValidateCertDetails.setEnabled(true);
					}
					
					else{
						JOptionPane.showMessageDialog(btncertBackup, "Certificate:    " + certObjectTxt +  "   Back Up Completed","title of dialog",2);
						btncertBackup.setEnabled(false);
						btnValidateCertDetails.setEnabled(true);
					}
					
					
				} catch (Exception e1) {
					// TODO Auto-generated catch block
					btncertBackup.setEnabled(false);
					btnValidateCertDetails.setEnabled(true);
					e1.printStackTrace();
					JOptionPane.showMessageDialog(btncertBackup, e1,"Error",2);
				}
				
				/*JOptionPane.showMessageDialog(btnValidate,
						Validate,"Validate Details",3);*/
				
				/*+"dpTier:" + dpTier
				
				*/
				
				
				
		     //    validateInformation(loginID,password,dpEnv,dpTier,dpTier,domain);
		    }
		});
	
		
	}
	
	@Override
	
	public void actionPerformed(ActionEvent e) {
		
		String loginID = ssoID.getText().trim();
		String password = passwordField.getText().trim();
	/*	String serType= serviceType.getSelection().getActionCommand();*/
		String dpEnv = dpEnvironment.getSelection().getActionCommand();
		String dpTier = tier.getSelection().getActionCommand();
		String boxTyp = boxType.getSelection().getActionCommand();
		String domain = (String) comboLanguage.getSelectedItem();
		
		String cerName = certificateNameText.getText().trim();
		String cerLocation = cerLocationText.getText().trim();
		
		System.out.println(domain+cerName+cerLocation);
		
		DP_Utility_Cert dp_Utility = new DP_Utility_Cert();
		try {
			dp_Utility.uploadCert(loginID,password,dpEnv,dpTier,boxTyp,domain,cerName,cerLocation);
			JOptionPane.showMessageDialog(btnImport, "file Imported","title of dialog",2);
			btnImport.setEnabled(false);
			btnValidate.setEnabled(true);
			
		} catch (Exception e1) {
			// TODO Auto-generated catch block
			e1.printStackTrace();
			JOptionPane.showMessageDialog(btnImport, "e1.printStackTrace()","Error",2);
		}
		
		
        
	}
}

