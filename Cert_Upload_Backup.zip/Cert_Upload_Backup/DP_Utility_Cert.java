package amaeriprise.DataPower.Cert_Upload_Backup;


import org.apache.commons.codec.binary.Base64;

import amaeriprise.DataPower.Cert_Upload_Backup.DP_exportLogic;

import java.io.BufferedOutputStream;
import java.io.BufferedReader;
import java.io.ByteArrayInputStream;
import java.io.FileOutputStream;
import java.io.FileReader;
import java.io.IOException;
import java.security.cert.CertificateException;
import java.security.cert.CertificateFactory;
import java.security.cert.X509Certificate;

import ameriprise.DataPower.Utility.EncodeDecodeString64;

public class DP_Utility_Cert {

	String E1app = "https://159.202.100.92:5550/service/mgmt/2004";
	String E2AppPri = "https://159.202.100.94:5550/service/mgmt/2004";
	String E2AppSec = "https://159.202.100.96:5550/service/mgmt/2004";
	String E3AppPri = "https://159.202.252.73:5550/service/mgmt/2004";
	String E3AppSec = "https://159.202.252.74:5550/service/mgmt/2004";
	
	String E1Web = "https://159.202.48.36:5550/service/mgmt/2004";
	String E2WebPri = "https://159.202.48.30:5550/service/mgmt/2004";
	String E2WebSec = "https://159.202.48.33:5550/service/mgmt/2004";
	String E3WebPri = "https://159.202.119.26:5550/service/mgmt/2004";
	String E3WebSec = "https://159.202.119.27:5550/service/mgmt/2004";

	CallDataPower_cert callDataPower = new CallDataPower_cert();

	public String uploadCert(String loginID, String password, String dpEnv, String dpTier,
			String boxTyp, String domain, String cerName, String cerLocation) throws Exception {

		
		
		
		String dpURL = dpURL(dpEnv ,dpTier, boxTyp);
		
		String response = null ;
		
		EncodeFileToBase64Binary base64Binary = new EncodeFileToBase64Binary();
		
		//String CertificateName = "test1.cer";
		
		String CertificateLocation = cerLocation;
		
		String CertificateName =  cerName;
		
		String Base64Cert = base64Binary.EncodedCertfile(CertificateLocation);
		
		System.out.println("Base64Cert::" + Base64Cert);
		
	/*	if(CertificateName.contains(".cer"))
		{
			
		}*/
		
		String inputXML = generateInputXmlForCertupload(domain,CertificateName, Base64Cert);
		
		 response = 	callDataPower.callDP(dpURL, inputXML, loginID, password,domain);
		
		
		if(response.contains("Authentication failure" ))
		{
			return "Authentication failure";
		}
		else {
			return "All Good";
		}
		

	
	}
	
	
	public String refreshCertObject(String loginID, String password, String dpEnv, String dpTier,
			String boxTyp, String domain, String cerName, String cerLocation, String cryptoCertObj) throws Exception {
		
		String dpURL = dpURL(dpEnv ,dpTier, boxTyp);
		
		
			String inputXML = generateInputXmlForCertObjRefresh(domain,cryptoCertObj);

			String response = 	callDataPower.callDP(dpURL, inputXML, loginID, password,domain);
			
			System.out.println("Refresh Crypto Obj resposne::/n"+ response);
			
			String CertObjectNotUpMsg = "certificate object"+" '"+cryptoCertObj+"' "+"is not up" ;
			
			System.out.println(CertObjectNotUpMsg);
			if(response.contains("Authentication failure")) 
			{
				
				return "Authentication failure";
			}
			
			
			
			else if (response.contains("Configuration not found")) {
				return "Configuration not found";
			}
			else {
				return "All Good";
			}
			
		
	}


	public String CryptoCertObjectUpload(String loginID, String password, String dpEnv, String dpTier,
			String boxTyp, String domain, String cerName, String cerLocation, String cryptoCertObj, String CCUpload) throws Exception {
		
			String dpURL = dpURL(dpEnv ,dpTier, boxTyp);
			
			String inputXML = generateInputXmlForCertObjCreate(domain,cerName,CCUpload);

			String response = callDataPower.callDP(dpURL, inputXML, loginID, password,domain);
			
			System.out.println("Cert Crypto Upload resposne::/n"+ response);
			
			if(response.contains("Authentication failure"))
			{
				
				return "Authentication failure";
			}
			else {
				return "All Good";
			}
			
			
			
	}
	
	
	
	public String CertBackup(String loginID, String password, String dpEnv, String dpTier,
			String boxTyp, String domain, String certBackup, String cerSaveDirtxt, String cerSaveAstxt) throws Exception {
		
		String dpURL = dpURL(dpEnv ,dpTier, boxTyp);
		
		DP_exportLogic dp_exportLogic = new DP_exportLogic();
		EncodeDecodeString64 encodeDecodeString64 = new EncodeDecodeString64();
		
			String inputXML = generateInputXmlForCertBackup(domain,certBackup);

			String response = 	callDataPower.callDP(dpURL, inputXML, loginID, password,domain);
			
			if(response.contains("Authentication failure"))
			{
				
				return "Authentication failure";
			}
			else if (response.contains("Cannot read the specified file")) {
				return "Cannot read the specified file";
			}
			else {
				
				System.out.println("response::"+response);
				
				String base64File = dp_exportLogic.exportFunction(response,"dp:file");
				
				System.out.println("base64File::"+base64File);
				
				byte[] decodedFile = encodeDecodeString64.Decode(base64File);
				
				System.out.println("decodedFile::"+decodedFile);
				
				
				/*System.out.println(decodedFile);*/
				
				
				
				String extractedFile = cerSaveDirtxt+"/"+certBackup+".txt";
				
				if (decodedFile != null) {
					try (BufferedOutputStream out = new BufferedOutputStream(new FileOutputStream(extractedFile), 4096)) {
			            out.write(decodedFile);
			        }
				}
				
				// Buffer Reader
				
				
				String readFile = "";
				
				try (BufferedReader br = new BufferedReader(new FileReader(extractedFile))) {

					String sCurrentLine;

					while ((sCurrentLine = br.readLine()) != null) {
						readFile = readFile + sCurrentLine;
					}

				} catch (IOException e) {
					e.printStackTrace();
				}

				System.out.println(readFile);
				
				String exported_Certificate = dp_exportLogic.exportFunction(readFile,"certificate");
				
				System.out.println("base64_cer::"+ exported_Certificate);
				
				
				
				String usableCertificate = exported_Certificate;
				
				
				String extractedCert = cerSaveDirtxt+"/"+cerSaveAstxt.replace(".cer", "")+".cer";
				
				
				
				X509Certificate cert = convertToX509Cert(usableCertificate);
				
				
				if (cert != null) {
					try (BufferedOutputStream out = new BufferedOutputStream(new FileOutputStream(extractedCert), 4096)) {
			            out.write(cert.getEncoded());
			        }
				}
				
				return "All Good";
				
			}
			
			
			
			
			
		
	}

	
	
	public String generateInputXmlForCertObjRefresh(String domain, String cryptoCertObj)
	
	{
		
		String inputXML = null;

		inputXML = "<soapenv:Envelope xmlns:soapenv=" + '"' + "http://schemas.xmlsoap.org/soap/envelope/" + '"'
					+ " xmlns:man=" + '"' + "http://www.datapower.com/schemas/management" + '"' + ">"
					+ "<soapenv:Header/><soapenv:Body><man:request domain=" + '"' + domain + '"' + ">"
					+ "<man:modify-config> <CryptoCertificate name=" +'"' + cryptoCertObj + '"' + ">" + "<mAdminState>disabled</mAdminState>" 
					+ " </CryptoCertificate>"+"</man:modify-config>"
					+"<man:do-action><SaveConfig/></man:do-action>" 				
					+"<man:modify-config> <CryptoCertificate name=" +'"' + cryptoCertObj + '"' + ">" + "<mAdminState>enabled</mAdminState>" 
							+ " </CryptoCertificate>"+"</man:modify-config>"+
					"</man:request></soapenv:Body></soapenv:Envelope>";

		System.out.println("Cert Obj Refresh XML::\n"+ inputXML );
	        
	          return inputXML;    
	}
	
	
public String generateInputXmlForCertObjCreate(String domain, String cerName, String CCUpload)
	
	{
		
		String inputXML = null;

		inputXML = "<soapenv:Envelope xmlns:soapenv=" + '"' + "http://schemas.xmlsoap.org/soap/envelope/" + '"'
					+ " xmlns:man=" + '"' + "http://www.datapower.com/schemas/management" + '"' + ">"
					+ "<soapenv:Header/><soapenv:Body><man:request domain=" + '"' + domain + '"' + ">"
					+ "<man:set-config> <CryptoCertificate name=" +'"' + CCUpload + '"' + ">" + "<mAdminState>enabled</mAdminState>"
					+ "<Filename>" + "cert:///" + cerName  + "</Filename>"
					+ " </CryptoCertificate>"+"</man:set-config>"
					+"<man:do-action><SaveConfig/></man:do-action>" +
					"</man:request></soapenv:Body></soapenv:Envelope>";
		  
	          System.out.println("Cert Obj Creation XML::\n"+ inputXML );

	          return inputXML;    
	}
	
	
	
	
	public String generateInputXmlForCertupload(String domain, String CertificateName, String Base64Cert) {

		
		String inputXML = null;

		inputXML = "<soapenv:Envelope xmlns:soapenv=" + '"' + "http://schemas.xmlsoap.org/soap/envelope/" + '"'
					+ " xmlns:man=" + '"' + "http://www.datapower.com/schemas/management" + '"' + ">"
					+ "<soapenv:Header/><soapenv:Body><man:request domain=" + '"' + domain + '"' + ">"
					+ "<man:set-file name=" + '"' + "cert:///" +CertificateName + '"' + ">" + Base64Cert + "</man:set-file></man:request></soapenv:Body></soapenv:Envelope>";
		  
		System.out.println("Cert upload XML::\n" + inputXML);
	          
			return inputXML;    
	     }     
	
	
	
public String generateInputXmlForCertBackup(String domain, String certBackup) {

		
		String inputXML = null;

		inputXML = "<soapenv:Envelope xmlns:soapenv=" + '"' + "http://schemas.xmlsoap.org/soap/envelope/" + '"'
					+ " xmlns:man=" + '"' + "http://www.datapower.com/schemas/management" + '"' + ">"
					+ "<soapenv:Header/><soapenv:Body><man:request domain=" + '"' + domain + '"' + ">"
					+ "<man:do-action>" 
					+"<CryptoExport><ObjectType>cert</ObjectType>" +"<ObjectName>" + certBackup +"</ObjectName>"+" <OutputFilename>"+certBackup+"</OutputFilename>"
					+ "</CryptoExport></man:do-action>"
					+ "<man:get-file name=" + '"' + "temporary:///"+certBackup + '"' + "/>" 
					+"</man:request></soapenv:Body></soapenv:Envelope>";
		  
		System.out.println("Cert Backup XML::" + inputXML);
		
	          
			return inputXML;    
	     } 
	
	


public static X509Certificate convertToX509Cert(String certificateString) throws CertificateException {
    X509Certificate certificate = null;
    CertificateFactory cf = null;
    try {
        if (certificateString != null && !certificateString.trim().isEmpty()) {
            
            byte[] certificateData = Base64.decodeBase64(certificateString);
            cf = CertificateFactory.getInstance("X509");
            certificate = (X509Certificate) cf.generateCertificate(new ByteArrayInputStream(certificateData));
        }
    } catch (CertificateException e) {
        throw new CertificateException(e);
    }
    return certificate;
}


	
	public String dpURL(String dpEnv, String dpTier, String boxTyp)
	{
	String dpURL = null;
	
	if (dpEnv == "E1" && dpTier == "AppTier" && (boxTyp == "Primary" || boxTyp == "Secondary")) {
		dpURL = E1app;
	}
	if (dpEnv == "E2" && dpTier == "AppTier" && boxTyp == "Primary") {
		dpURL = E2AppPri;
	}
	if (dpEnv == "E2" && dpTier == "AppTier" && boxTyp == "Secondary") {
		dpURL = E2AppSec;
	}
	if (dpEnv == "E3" && dpTier == "AppTier" && boxTyp == "Primary") {
		dpURL = E3AppPri;
	}
	if (dpEnv == "E3" && dpTier == "AppTier" && boxTyp == "Secondary") {
		dpURL = E3AppSec;
	}
	
	if (dpEnv == "E1" && dpTier == "WebTier" && (boxTyp == "Primary" || boxTyp == "Secondary")) {
		dpURL = E1Web;
	}
	if (dpEnv == "E2" && dpTier == "WebTier" && boxTyp == "Primary") {
		dpURL = E2WebPri;
	}
	if (dpEnv == "E2" && dpTier == "WebTier" && boxTyp == "Secondary") {
		dpURL = E2WebSec;
	}
	if (dpEnv == "E3" && dpTier == "WebTier" && boxTyp == "Primary") {
		dpURL = E3WebPri;
	}
	if (dpEnv == "E3" && dpTier == "WebTier" && boxTyp == "Secondary") {
		dpURL = E3WebSec;
	}
	
	return dpURL;
	}
	
	
	}


