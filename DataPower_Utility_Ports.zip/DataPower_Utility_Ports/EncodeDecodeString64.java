package DataPower_Utility_Ports;


import java.io.IOException;
import org.apache.commons.codec.binary.Base64;

public class EncodeDecodeString64 {

    public byte[] Decode(String Encoded) throws IOException {

    	String str = Encoded;
        // encode data using BASE64
        byte[] decoded = Base64.decodeBase64(str);
       // System.out.println(new String(decoded, "UTF-8") + "\n");
        
      //  System.out.println(new String(decoded, "UTF-8") + "\n");
        
        
        return decoded;
          
        

    }
}