package DataPower_Utility_Ports;

import java.awt.EventQueue;
import java.awt.TextField;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

import javax.swing.JFrame;
import javax.swing.JPanel;
import javax.swing.border.EmptyBorder;
import javax.swing.JLabel;
import javax.swing.JOptionPane;
import javax.swing.ButtonGroup;
import javax.swing.JButton;
import javax.swing.JComboBox;
import javax.swing.JRadioButton;
import javax.swing.JPasswordField;
import javax.swing.JTextArea;

public class ExportServices_Swing extends JFrame implements ActionListener {

	public JPanel contentPane;
	public JPasswordField passwordField;
	
	public JTextArea ssoID,serviceNameText,saveLocationText;
	
	public JButton btnExport; 
	public ButtonGroup serviceType,dpEnvironment,tier,boxType;
	
	JComboBox<String> comboLanguage = new JComboBox<String>();
	
	TextField text = new TextField(20);
    private int numClicks = 0;

	/**
	 * Launch the application.
	 * @return 
	 */
  /*  public static void exportService()
    {
    	EventQueue.invokeLater(new Runnable() {
			public void run() {
				try {
					ExportServices frame = new ExportServices();
					frame.setVisible(true);
				} catch (Exception e) {
					e.printStackTrace();
				}
			}
		});
    }*/
    
	public static void main(String[] args) {
		EventQueue.invokeLater(new Runnable() {
			public void run() {
				try {
					ExportServices_Swing frame = new ExportServices_Swing();
					frame.setVisible(true);
				} catch (Exception e) {
					e.printStackTrace();
				}
			}
		});
	}

	/**
	 * Create the frame.
	 */
	public ExportServices_Swing() {
		setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		setBounds(100, 100, 533, 384);
		contentPane = new JPanel();
		contentPane.setBorder(new EmptyBorder(5, 5, 5, 5));
		setContentPane(contentPane);
		contentPane.setLayout(null);
		
		JLabel lblNewLabel = new JLabel("Welcome to Data Power Export Service Utility");
		lblNewLabel.setBounds(113, 0, 300, 31);
		contentPane.add(lblNewLabel);
		
		JLabel lblNewLabel_1 = new JLabel("SSO ID");
		lblNewLabel_1.setBounds(37, 44, 60, 20);
		contentPane.add(lblNewLabel_1);
		
		ssoID = new JTextArea();
		ssoID.setBounds(128, 42, 227, 22);
		contentPane.add(ssoID);
		
		JLabel lblNewLabel_2 = new JLabel("Password");
		lblNewLabel_2.setBounds(37, 74, 60, 20);
		contentPane.add(lblNewLabel_2);
		
		passwordField = new JPasswordField();
		passwordField.setBounds(128, 74, 227, 20);
		contentPane.add(passwordField);
		
		
		JLabel lblNewLabel_4 = new JLabel("Service Type");
		lblNewLabel_4.setBounds(37, 99, 79, 14); //
		contentPane.add(lblNewLabel_4);
		
		JRadioButton wsp = new JRadioButton("WSP");
		wsp.setBounds(128, 95, 60, 23);
		wsp.setSelected(true);
		wsp.setActionCommand("WSGateway");
		contentPane.add(wsp);
		
		JRadioButton mpgw = new JRadioButton("MPGW");
		mpgw.setBounds(198, 95, 70, 23);
		mpgw.setSelected(true);
		mpgw.setActionCommand("MultiProtocolGateway");
		contentPane.add(mpgw);
		
		JRadioButton xmlfw = new JRadioButton("XMLFW");
		xmlfw.setBounds(268, 95, 70, 23);
		xmlfw.setSelected(true);
		xmlfw.setActionCommand("XMLFirewallService");
		contentPane.add(xmlfw);
		

		 serviceType = new ButtonGroup();
		serviceType.add(wsp);
		serviceType.add(mpgw);
		serviceType.add(xmlfw);
		
		JLabel lblNewLabel_3 = new JLabel("DP Env");
		lblNewLabel_3.setBounds(37, 124, 46, 14); 
		contentPane.add(lblNewLabel_3);
		
		JRadioButton dpE1 = new JRadioButton("E1");
		dpE1.setBounds(128, 121, 40, 23);
		dpE1.setSelected(true);
		dpE1.setActionCommand("E1");
		contentPane.add(dpE1);
		
		JRadioButton dpE2 = new JRadioButton("E2");
		dpE2.setBounds(198, 121, 40, 23);
		dpE2.setSelected(true);
		dpE2.setActionCommand("E2");
		contentPane.add(dpE2);
		
		JRadioButton dpE3 = new JRadioButton("E3");
		dpE3.setBounds(268, 120, 40, 23);
		dpE3.setSelected(true);
		dpE3.setActionCommand("E3");
		contentPane.add(dpE3);
		
		dpEnvironment = new ButtonGroup();
		dpEnvironment.add(dpE1);
		dpEnvironment.add(dpE2);
		dpEnvironment.add(dpE3);
		
		JRadioButton appTier = new JRadioButton("AppTier");
		appTier.setBounds(128, 145, 70, 23);
		appTier.setSelected(true);
		appTier.setActionCommand("AppTier");
		contentPane.add(appTier);
		
		JRadioButton webTier = new JRadioButton("WebTier");
		webTier.setBounds(198, 147, 70, 23);
		webTier.setSelected(true);
		webTier.setActionCommand("AppTier");
		contentPane.add(webTier);
		
		tier = new ButtonGroup();
		tier.add(appTier);
		tier.add(webTier);
		
		
		JLabel lblboxtyp = new JLabel("boxType");
		contentPane.add(lblboxtyp);
		
		JRadioButton primary = new JRadioButton("Primary");
		primary.setBounds(128, 171, 70, 23);
		primary.setSelected(true);
		primary.setActionCommand("Primary");
		contentPane.add(primary);
		
		JRadioButton secondary = new JRadioButton("Secondary");
		secondary.setBounds(198, 173, 110, 23);
		secondary.setSelected(true);
		secondary.setActionCommand("Secondary");
		contentPane.add(secondary);
		
		boxType = new ButtonGroup();
		boxType.add(primary);
		boxType.add(secondary);
		
		

		JLabel lblDomain = new JLabel("Domain");
		lblDomain.setBounds(37, 205, 46, 14);
		contentPane.add(lblDomain);
		
				
		comboLanguage.addItem("E0Domain");
		comboLanguage.addItem("E1Domain");
		comboLanguage.addItem("DudeDomain");
		comboLanguage.addItem("E0WebDomain");
		comboLanguage.addItem("WebDomain");
		
		comboLanguage.setEditable(false);
		comboLanguage.setBounds(128, 201, 150, 23);
		
		contentPane.add(comboLanguage);
		
		
		
		JLabel serviceName = new JLabel("Service Name");
		serviceName.setBounds(37, 238, 79, 14);
		contentPane.add(serviceName);
		
		serviceNameText = new JTextArea();
		serviceNameText.setBounds(128, 233, 227, 22);
		contentPane.add(serviceNameText);
		
		
		
		JLabel savingLocation = new JLabel("Save As");
		savingLocation.setBounds(37, 268, 79, 20); 
		contentPane.add(savingLocation);
		
		saveLocationText = new JTextArea();
		saveLocationText.setBounds(128, 266, 227, 22);
		contentPane.add(saveLocationText);
		
		
		 btnExport = new JButton("Export");
		btnExport.setBounds(160, 301, 89, 23);
		contentPane.add(btnExport);
		
		JLabel lblTier = new JLabel("Tier");
		lblTier.setBounds(37, 149, 46, 14);
		contentPane.add(lblTier);
		
		JLabel lblBoxtype = new JLabel("BoxType");
		lblBoxtype.setBounds(37, 175, 46, 14);
		contentPane.add(lblBoxtype);
		
		btnExport.addActionListener(this);
		
		
		
		
	
	}

	@Override
	
	
	public void actionPerformed(ActionEvent e) {
		String loginID = ssoID.getText();
		String password = passwordField.getText();
		String serType= serviceType.getSelection().getActionCommand();
		String dpEnv = dpEnvironment.getSelection().getActionCommand();
		String dpTier = tier.getSelection().getActionCommand();
		String boxTyp = boxType.getSelection().getActionCommand();
		String domain = (String) comboLanguage.getSelectedItem();
		String serName = serviceNameText.getText();
		String saveAs = saveLocationText.getText();
		
		System.out.println(domain+serName+serType);
		
		
		DP_Utility dp_Utility = new DP_Utility();
		try {
			dp_Utility.exportFunction(loginID,password,serType,dpEnv,dpTier,boxTyp,domain,serName,saveAs);
		} catch (Exception e1) {
			// TODO Auto-generated catch block
			e1.printStackTrace();
		}
		
		
		
		System.out.println(domain+serName);
		
		JOptionPane.showMessageDialog(btnExport, "fileExported","title of dialog",2);
        
	}
}
