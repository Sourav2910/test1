package DataPower_Utility_Ports;


import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.io.FileWriter;

public class DP_Utility {

	String E1app = "https://159.202.100.92:5550/service/mgmt/2004";
	String E2AppPri = "https://159.202.100.94:5550/service/mgmt/2004";
	String E2AppSec = "https://159.202.100.96:5550/service/mgmt/2004";
	String E3AppPri = "https://159.202.252.73:5550/service/mgmt/2004";
	String E3AppSec = "https://159.202.252.74:5550/service/mgmt/2004";

	CallDataPower callDataPower = new CallDataPower();

	
	public void exportFunction(String loginID, String password, String serType, String dpEnv, String dpTier,
			String boxTyp, String domain, String serName, String saveAs) throws Exception {
		String dpURL = null;

		if (dpEnv == "E1" && dpTier == "AppTier" && (boxTyp == "Primary" || boxTyp == "Secondary")) {
			dpURL = E1app;
		}
		if (dpEnv == "E2" && dpTier == "AppTier" && boxTyp == "Primary") {
			dpURL = E2AppPri;
		}
		if (dpEnv == "E2" && dpTier == "AppTier" && boxTyp == "Secondary") {
			dpURL = E2AppSec;
		}
		if (dpEnv == "E3" && dpTier == "AppTier" && boxTyp == "Primary") {
			dpURL = E3AppPri;
		}
		if (dpEnv == "E3" && dpTier == "AppTier" && boxTyp == "Secondary") {
			dpURL = E3AppSec;
		}

		String inputXML = generateInputXml(domain, serType, serName);

		callDataPower.callDP(dpURL, inputXML, loginID, password, serName,domain);
	}

	public String generateInputXml(String domain, String servTyp, String servNam) {

		
		/*  String inputXML=
		  "C:/Tool/DataPower_Utility_Application/src/ameriprise/DataPower/Utility/SomaRequest.xml";*/
		 
		  	
		String inputXML = "<soapenv:Envelope xmlns:soapenv=" + '"' + "http://schemas.xmlsoap.org/soap/envelope/" + '"'
				+ " xmlns:man=" + '"' + "http://www.datapower.com/schemas/management" + '"' + ">"
				+ "<soapenv:Header/><soapenv:Body><man:request domain=" + '"' + domain + '"' + ">"
				+ "<man:do-export format=" + '"' + "ZIP" + '"' + ">" + "<man:object class=" + '"' + servTyp + '"'
				+ " name=" + '"' + servNam + '"' + " ref-objects=" + '"' + "true" + '"' + " ref-files=" + '"' + "true"
				+ '"' + "/>" + "</man:do-export></man:request></soapenv:Body></soapenv:Envelope>";
		  
		  try{    
	           FileWriter fw=new FileWriter("C:/Tool/DataPower_Utility_Application/src/ameriprise/DataPower/Utility/SomaRequest1.xml");    
	           fw.write(inputXML);    
	           fw.close();    
	          }catch(Exception e){System.out.println(e);}    
	          System.out.println("Success...SomaRequest1.xml generated");
	          
	          String inputXMLFile=
	        		  "C:/Tool/DataPower_Utility_Application/src/ameriprise/DataPower/Utility/SomaRequest1.xml";
			return inputXMLFile;    
	     }     

	}


