package DataPower_Utility_Ports;

import java.io.File;
import java.io.IOException;
import java.io.StringReader;

import javax.xml.parsers.DocumentBuilder;
import javax.xml.parsers.DocumentBuilderFactory;
import javax.xml.parsers.ParserConfigurationException;

import org.w3c.dom.NodeList;
import org.xml.sax.InputSource;
import org.xml.sax.SAXException;
import org.w3c.dom.Document;

public class DP_exportLogic {
	
	
	public String exportFunction(String input){
		
	
	 DocumentBuilderFactory factory = DocumentBuilderFactory.newInstance();
     DocumentBuilder builder;
     InputSource is;
     String exportedZip = "null";
     try {
         builder = factory.newDocumentBuilder();
         is = new InputSource(new StringReader(input));
         Document doc = builder.parse(is);
         NodeList list = doc.getElementsByTagName("dp:file");
        /* System.out.println(list.item(0).getTextContent());*/
         exportedZip  = list.item(0).getTextContent();
     } catch (ParserConfigurationException e) {
     } catch (SAXException e) {
     } catch (IOException e) {
     }
     return exportedZip;
     
	}

}
