package ameriprise.DataPower.sendMail;

public class SendMail {

	public static void main(String[] args) {
		// TODO Auto-generated method stub

	}

}
