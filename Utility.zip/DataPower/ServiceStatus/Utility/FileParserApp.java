package ameriprise.DataPower.ServiceStatus.Utility;

import java.io.File;
import java.io.IOException;
import java.util.HashMap;
import java.util.Map;

import javax.xml.parsers.DocumentBuilder;
import javax.xml.parsers.DocumentBuilderFactory;
import javax.xml.parsers.ParserConfigurationException;
import javax.xml.xpath.XPath;
import javax.xml.xpath.XPathConstants;
import javax.xml.xpath.XPathExpressionException;
import javax.xml.xpath.XPathFactory;

import org.w3c.dom.Document;
import org.w3c.dom.Element;
import org.w3c.dom.Node;
import org.w3c.dom.NodeList;
import org.xml.sax.SAXException;

public class FileParserApp {

	private boolean checkNullAndEmpty(String expValue) {
		if (null != expValue && expValue != "")
			return true;
		else
			return false;
	}

	private Document generateDocObject(String fileName) {
		File inputFile = null;
		DocumentBuilder dBuilder = null;
		Document doc = null;
		try {
			inputFile = new File(fileName);
			dBuilder = DocumentBuilderFactory.newInstance().newDocumentBuilder();
			doc = dBuilder.parse(inputFile);
			doc.getDocumentElement().normalize();
		} catch (ParserConfigurationException e1) {
			e1.printStackTrace();
		} catch (SAXException e2) {
			e2.printStackTrace();
		} catch (IOException e3) {
			e3.printStackTrace();
		}
		return doc;
	}

	// ServiceStatus

	public Map<String, String> serviceStatus(Element eElement) {
		Map<String, String> val = new HashMap<String, String>();

		if (eElement.getElementsByTagName("LocalPort").item(0).getTextContent() != null) {
			val.put("LocalPort", eElement.getElementsByTagName("LocalPort").item(0).getTextContent());
		} else {
			val.put("LocalPort", "Data not present");
		}

		if (eElement.getElementsByTagName("FshClass").item(0).getTextContent() != null) {
			val.put("FshClass", eElement.getElementsByTagName("FshClass").item(0).getTextContent());
		} else {
			val.put("FshClass", "Data not present");
		}

		if (eElement.getElementsByTagName("FshName").item(0).getTextContent() != null) {
			val.put("FshName", eElement.getElementsByTagName("FshName").item(0).getTextContent());
		} else {
			val.put("FshName", "Data not present");
		}

		if (eElement.getElementsByTagName("FshStatus").item(0).getTextContent() != null) {
			val.put("FshStatus", eElement.getElementsByTagName("FshStatus").item(0).getTextContent());
		} else {
			val.put("FshStatus", "Data not present");
		}

		if (eElement.getElementsByTagName("ServiceClass").item(0).getTextContent() != null) {
			val.put("ServiceClass", eElement.getElementsByTagName("ServiceClass").item(0).getTextContent());
		} else {
			val.put("ServiceClass", "Data not present");
		}

		if (eElement.getElementsByTagName("ServiceName").item(0).getTextContent() != null) {
			val.put("ServiceName", eElement.getElementsByTagName("ServiceName").item(0).getTextContent());
		} else {
			val.put("ServiceName", "Data not present");
		}

		if (eElement.getElementsByTagName("GatewayStatus").item(0).getTextContent() != null) {
			val.put("GatewayStatus", eElement.getElementsByTagName("GatewayStatus").item(0).getTextContent());
		} else {
			val.put("GatewayStatus", "Data not present");
		}

		/*
		 * val.put("LocalPort",
		 * eElement.getElementsByTagName("LocalPort").item(0).getTextContent());
		 * val.put("FshClass",
		 * eElement.getElementsByTagName("FshClass").item(0).getTextContent());
		 * val.put("FshName",
		 * eElement.getElementsByTagName("FshName").item(0).getTextContent());
		 * val.put("FshStatus",
		 * eElement.getElementsByTagName("FshStatus").item(0).getTextContent());
		 * val.put("ServiceClass",
		 * eElement.getElementsByTagName("ServiceClass").item(0).getTextContent(
		 * )); val.put("ServiceName",
		 * eElement.getElementsByTagName("ServiceName").item(0).getTextContent()
		 * ); val.put("GatewayStatus",
		 * eElement.getElementsByTagName("GatewayStatus").item(0).getTextContent
		 * ());
		 */

		return val;
	}

	public Map<String, Map> getService(String inputFileName, String nodeName) throws XPathExpressionException {
		String expression = null;
		XPath xPath = null;
		NodeList nodeList = null;
		Node nNode = null;
		Document doc = null;

		Map<String, Map> serviceStatusMap = new HashMap<String, Map>();
		Map<String, String> serviceStatusMapValues = null;

		if (checkNullAndEmpty(nodeName)) {
			doc = generateDocObject(inputFileName);
			expression = "/Envelope/Body/response/status/".concat(nodeName);
			xPath = XPathFactory.newInstance().newXPath();

			if (null != xPath && checkNullAndEmpty(expression)) {
				nodeList = (NodeList) xPath.compile(expression).evaluate(doc, XPathConstants.NODESET);
				System.out.println(nodeList.getLength());
				for (int i = 0; i < nodeList.getLength(); i++) {
					nNode = nodeList.item(i);
					if (nNode.getNodeType() == Node.ELEMENT_NODE) {
						Element eElement = (Element) nNode;
						serviceStatusMapValues = serviceStatus(eElement);
						serviceStatusMap.put("serviceStatus".concat(String.valueOf(i)), serviceStatusMapValues);
					}
				}
			}
		}
		System.out.println(serviceStatusMap);
		return serviceStatusMap;
	}
}
