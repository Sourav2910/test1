package ameriprise.DataPower.ServiceStatus.Utility;

import java.io.File;
import java.io.FileOutputStream;
import java.io.IOException;
import java.util.Collection;
import java.util.HashMap;
import java.util.Map;
import java.util.Map.Entry;

import javax.xml.parsers.DocumentBuilder;
import javax.xml.parsers.DocumentBuilderFactory;
import javax.xml.parsers.ParserConfigurationException;
import javax.xml.xpath.XPath;
import javax.xml.xpath.XPathConstants;
import javax.xml.xpath.XPathExpressionException;
import javax.xml.xpath.XPathFactory;

import org.apache.poi.hssf.usermodel.HSSFCell;
import org.apache.poi.hssf.usermodel.HSSFRow;
import org.apache.poi.hssf.usermodel.HSSFSheet;
import org.apache.poi.hssf.usermodel.HSSFWorkbook;
import org.w3c.dom.Document;
import org.w3c.dom.Element;
import org.w3c.dom.Node;
import org.w3c.dom.NodeList;
import org.xml.sax.SAXException;

public class FileParserRunner {

	public static void main(String[] args) {

		Map<String, Map<String, String>> mapResponse = null;

		String fileName = "C:/Tool/DataPower_Utility_Application/src/ameriprise/DataPower/ServiceStatus/Utility/ServiceStatus_output.xml";
		try {
			mapResponse = getService(fileName, "ServicesStatusPlus");

			// System.out.println(mapResponse);

			writeXLSFile(mapResponse);

			// System.out.println(mapResponse);

		} catch (Exception e) {
			e.printStackTrace();
		}
	}

	private static Map<String, Map<String, String>> getService(String inputFileName, String nodeName)
			throws XPathExpressionException {
		String expression = null;
		XPath xPath = null;
		NodeList nodeList = null;
		Node nNode = null;
		Document doc = null;
		FileParserApp parserObject = new FileParserApp();
		Map<String, Map<String, String>> serviceStatusMap = new HashMap<String, Map<String, String>>();
		Map<String, String> serviceStatusMapValues = null;

		if (checkNullAndEmpty(nodeName)) {
			doc = generateDocObject(inputFileName);
			expression = "/Envelope/Body/response/status/".concat(nodeName);
			xPath = XPathFactory.newInstance().newXPath();

			if (null != xPath && checkNullAndEmpty(expression)) {
				nodeList = (NodeList) xPath.compile(expression).evaluate(doc, XPathConstants.NODESET);
				for (int i = 0; i < nodeList.getLength(); i++) {
					nNode = nodeList.item(i);
					if (nNode.getNodeType() == Node.ELEMENT_NODE) {
						Element eElement = (Element) nNode;
						serviceStatusMapValues = parserObject.serviceStatus(eElement);
						serviceStatusMap.put("ServiceStatus".concat(String.valueOf(i)), serviceStatusMapValues);
					}
				}
			}
		}
		return serviceStatusMap;
	}

	private static boolean checkNullAndEmpty(String expValue) {
		if (null != expValue && expValue != "")
			return true;
		else
			return false;
	}

	private static Document generateDocObject(String fileName) {
		File inputFile = null;
		DocumentBuilder dBuilder = null;
		Document doc = null;
		try {
			inputFile = new File(fileName);
			dBuilder = DocumentBuilderFactory.newInstance().newDocumentBuilder();
			doc = dBuilder.parse(inputFile);
			doc.getDocumentElement().normalize();
		} catch (ParserConfigurationException e1) {
			e1.printStackTrace();
		} catch (SAXException e2) {
			e2.printStackTrace();
		} catch (IOException e3) {
			e3.printStackTrace();
		}
		return doc;
	}

	private static void writeXLSFile(Map<String, Map<String, String>> mapResponse) throws IOException {

		// Name of excel file
		String excelFileName = "C:/Users/ssingh140/Desktop/DataPowerExport/Test8.xls";
		// name of sheet
		String sheetName = "Sheet1";

		HSSFWorkbook wb = new HSSFWorkbook();
		HSSFSheet sheet = wb.createSheet(sheetName);

		Map<String, String> mapActualResponse = new HashMap<String, String>();
		Collection<String> collection = null;

		writetoXLSFile(mapResponse);

		/*
		 * for (Map.Entry<String, Map<String, String>> mp :
		 * mapResponse.entrySet()) { for (Map.Entry<String, String> vm :
		 * mp.getValue().entrySet()) { System.out.print(vm.getKey() + "/" +
		 * vm.getValue() + " ");
		 * 
		 * for (int r=1;r <= mapResponse.size(); r++ ) { List<String> list = new
		 * ArrayList<String>(); // list = vm.getValue();
		 * 
		 * HSSFRow row = sheet.createRow(r);
		 * 
		 * //iterating c number of columns for (int c=0;c < 5; c++ ) { HSSFCell
		 * cell = row.createCell(c);
		 * 
		 * cell.setCellValue("Cell "+r+" "+c); } } } System.out.println(); }
		 */

		/*
		 * Collection<String> collection = mapResponse.values();
		 * Iterator<String> iterator = collection.iterator();
		 */
		/* System.out.println(collection.toString().length()); */

		/*
		 * Iterator<String> iterator = collection.iterator(); // while loop
		 * while (iterator.t) { System.out.println("value= " + iterator.next());
		 * }
		 */

		/*
		 * for (int r=0;r < 5; r++ ) { HSSFRow row = sheet.createRow(r);
		 * 
		 * //iterating c number of columns for (int c=0;c < 5; c++ ) { HSSFCell
		 * cell = row.createCell(c);
		 * 
		 * cell.setCellValue("Cell "+r+" "+c); } }
		 */

		/*
		 * // iterating r number of rows for (int r = 0; r < 1; r++) { HSSFRow
		 * row = sheet.createRow(r); // while loop while (iterator.hasNext()) {
		 * int i=1; HSSFCell cell = row.createCell(i);
		 * cell.setCellValue(iterator.next()); i=i+1; // System.out.println(
		 * "value= " + iterator.next()); }
		 */
		// iterating c number of columns
		/*
		 * for (int c = 0; c < 7; c++) { HSSFCell cell = row.createCell(c);
		 * cell.setCellValue("Cell " + r + " " + c); } }
		 */

		FileOutputStream fileOut = new FileOutputStream(excelFileName);

		// write this workbook to an Outputstream.
		wb.write(fileOut);
		fileOut.flush();
		fileOut.close();
	}

	public static void writetoXLSFile(Map<String, Map<String, String>> mapResponse) throws IOException {

		System.out.println("in write");
		// Name of excel file
		String excelFileName = "C:/Users/ssingh140/Desktop/DataPowerExport/toshi.xls";
		// Name of sheet
		String sheetName = "Sheet1";

		HSSFWorkbook wb = new HSSFWorkbook();
		HSSFSheet sheet = wb.createSheet(sheetName);

		String[] headers = new String[] { "LocalPort", "FshClass", "FshName", "FshStatus", "FshStatus", "ServiceName",
				"GatewayStatus" };

		int r = 0;
		for (Map.Entry<String, Map<String, String>> mp : mapResponse.entrySet()) {
			HSSFRow row = sheet.createRow(r);
				System.out.println("in x :"+ headers.length);
				for (int x = 0; x < headers.length; x++) {
					row.createCell(x).setCellValue(headers[x]);
			}
			int c = 0;
			for (Map.Entry<String, String> vm : mp.getValue().entrySet()) {
				HSSFCell cell = row.createCell(c);

				cell.setCellValue(vm.getValue());
				c++;
			}
			r++;
		}

		FileOutputStream fileOut = new FileOutputStream(excelFileName);

		// write this workbook to an Outputstream.
		wb.write(fileOut);
		fileOut.flush();
		fileOut.close();
	}

}
