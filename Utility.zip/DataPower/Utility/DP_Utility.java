package ameriprise.DataPower.Utility;


import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.io.FileWriter;

import ameriprise.DataPower.Utility.EncodeFileToBase64Binary;

public class DP_Utility {

	String E1app = "https://159.202.100.92:5550/service/mgmt/2004";
	String E2AppPri = "https://159.202.100.94:5550/service/mgmt/2004";
	String E2AppSec = "https://159.202.100.96:5550/service/mgmt/2004";
	String E3AppPri = "https://159.202.252.73:5550/service/mgmt/2004";
	String E3AppSec = "https://159.202.252.74:5550/service/mgmt/2004";
	
	String E1Web = "https://159.202.48.36:5550/service/mgmt/2004";
	String E2WebPri = "https://159.202.48.30:5550/service/mgmt/2004";
	String E2WebSec = "https://159.202.48.33:5550/service/mgmt/2004";
	String E3WebPri = "https://159.202.119.26:5550/service/mgmt/2004";
	String E3WebSec = "https://159.202.119.27:5550/service/mgmt/2004";

	CallDataPower callDataPower = new CallDataPower();

	public void exportFunction(String loginID, String password, String serType, String dpEnv, String dpTier,
			String boxTyp, String domain, String serName, String saveAs) throws Exception {
		
		String dpURL = dpURLFetch(dpEnv ,dpTier, boxTyp);

		String inputXML = generateInputXmlforExport(domain, serType, serName);

		callDataPower.callDP(dpURL, inputXML, loginID, password, serName,domain,serType);
	}
	
	

	public String generateInputXmlforExport(String domain, String servTyp, String servNam) {

		
		/*  String inputXML=
		  "C:/Tool/DataPower_Utility_Application/src/ameriprise/DataPower/Utility/SomaRequest.xml";*/
		String inputXML = null;
		  	
		//<man:get-file name="local:///BETA_API_Map_424.xml"/>
		
		if(servTyp == "file") {
			
			inputXML = "<soapenv:Envelope xmlns:soapenv=" + '"' + "http://schemas.xmlsoap.org/soap/envelope/" + '"'
					+ " xmlns:man=" + '"' + "http://www.datapower.com/schemas/management" + '"' + ">"
					+ "<soapenv:Header/><soapenv:Body><man:request domain=" + '"' + domain + '"' + ">"
					+ "<man:get-file name=" + '"' + "local:///"+servNam + '"' + "/>" + "</man:request></soapenv:Body></soapenv:Envelope>";
			
		}
		else if(servTyp == "domain") {
			inputXML = "<soapenv:Envelope xmlns:soapenv=" + '"' + "http://schemas.xmlsoap.org/soap/envelope/" + '"'
					+ " xmlns:man=" + '"' + "http://www.datapower.com/schemas/management" + '"' + ">"
					+ "<soapenv:Header/><soapenv:Body><man:request domain=" + '"' + domain + '"' + ">"
					+ "<man:do-backup format=" + '"' + "ZIP" + '"' + ">" + "<man:domain name=" + '"' + domain + '"' +"/>" +"</man:do-backup></man:request></soapenv:Body></soapenv:Envelope>";
		}
		
		
		else{
			 	inputXML = "<soapenv:Envelope xmlns:soapenv=" + '"' + "http://schemas.xmlsoap.org/soap/envelope/" + '"'
					+ " xmlns:man=" + '"' + "http://www.datapower.com/schemas/management" + '"' + ">"
					+ "<soapenv:Header/><soapenv:Body><man:request domain=" + '"' + domain + '"' + ">"
					+ "<man:do-export format=" + '"' + "ZIP" + '"' + ">" + "<man:object class=" + '"' + servTyp + '"'
					+ " name=" + '"' + servNam + '"' + " ref-objects=" + '"' + "true" + '"' + " ref-files=" + '"' + "true"
					+ '"' + "/>" + "</man:do-export></man:request></soapenv:Body></soapenv:Envelope>";
		}
		
		
		  
		  try{    
			  
			  
	           FileWriter fw=new FileWriter("C:/Tool/DataPower_Utility_Application/src/ameriprise/DataPower/Utility/SOMA_Xml_used.xml");    
	           fw.write(inputXML);    
	           fw.close();    
	          }catch(Exception e){System.out.println(e);}    
	          System.out.println("Success...SOMA_Xml_used.xml generated");
	          
	          String inputXMLFile=
	        		  "C:/Tool/DataPower_Utility_Application/src/ameriprise/DataPower/Utility/SOMA_Xml_used.xml";
			return inputXMLFile;    
	     }     
	
	
	public void importFunction(String loginID, String password, String serType, String dpEnv, String dpTier,
			String boxTyp, String domain, String serName, String saveAs) throws Exception {
		
		String dpURL = dpURLFetch(dpEnv ,dpTier, boxTyp);

EncodeFileToBase64Binary base64Binary = new EncodeFileToBase64Binary();
		
		//String CertificateName = "test1.cer";
			

		saveAs = "C:/Tool/DataPower_Utility_Application/src/ameriprise/DataPower/Utility/Naviplan_AWM_OFM_BATCH_App_MPGW.zip";
		
		String Base64file = base64Binary.EncodedCertfile(saveAs);
		
		
		System.out.println("Base64file::" + Base64file);
		
		
		String inputXML = generateInputXmlforImport(domain, serType, serName,Base64file);

		callDataPower.callDP(dpURL, inputXML, loginID, password, serName,domain,serType);
	}
	
	
public String generateInputXmlforImport(String domain, String servTyp, String servNam, String Base64file) {

		
		/*  String inputXML=
		  "C:/Tool/DataPower_Utility_Application/src/ameriprise/DataPower/Utility/SomaRequest.xml";*/
		String inputXML = null;
		
		
		
		  	
		//<man:get-file name="local:///BETA_API_Map_424.xml"/>
		/*	<man:do-import source-type="ZIP" dry-run="false" overwrite-objects="false" overwrite-files="false">
		<man:input-file>
		***BASE64 Encoded Data***
		</man:input-file>*/ 
		
		
		if(servTyp == "file") {
			
			inputXML = "<soapenv:Envelope xmlns:soapenv=" + '"' + "http://schemas.xmlsoap.org/soap/envelope/" + '"'
					+ " xmlns:man=" + '"' + "http://www.datapower.com/schemas/management" + '"' + ">"
					+ "<soapenv:Header/><soapenv:Body><man:request domain=" + '"' + domain + '"' + ">"
					+ "<man:set-file name=" + '"' + "local:///" +servNam + '"' + ">" + Base64file + "</man:set-file></man:request></soapenv:Body></soapenv:Envelope>";
			
		}
		else if(servTyp == "service") {
			inputXML = "<soapenv:Envelope xmlns:soapenv=" + '"' + "http://schemas.xmlsoap.org/soap/envelope/" + '"'
					+ " xmlns:man=" + '"' + "http://www.datapower.com/schemas/management" + '"' + ">"
					+ "<soapenv:Header/><soapenv:Body><man:request domain=" + '"' + domain + '"' + ">"
					+ "<man:do-import source-type=" + '"' + "ZIP" + '"' + " dry-run=" + '"' + "false" + '"'
					+ " overwrite-objects=" + '"' + "false" + '"'
					
					+ ">" + "<man:input-file>" + Base64file +"</man:input-file></man:do-import></man:request></soapenv:Body></soapenv:Envelope>";
		}
		
		
		  
		  try{    
			  
			  
	           FileWriter fw=new FileWriter("C:/Tool/DataPower_Utility_Application/src/ameriprise/DataPower/Utility/SOMA_Xml_used_Export.xml");    
	           fw.write(inputXML);    
	           fw.close();    
	          }catch(Exception e){System.out.println(e);}    
	          System.out.println("Success...SOMA_Xml_used_Export.xml generated");
	          
	          String inputXMLFile=
	        		  "C:/Tool/DataPower_Utility_Application/src/ameriprise/DataPower/Utility/SOMA_Xml_used_Export.xml";
			return inputXMLFile;    
	     }     

	
	
	public String dpURLFetch(String dpEnv, String dpTier, String boxTyp)
	{
	String dpURL = null;
	
	if (dpEnv == "E1" && dpTier == "AppTier" && (boxTyp == "Primary" || boxTyp == "Secondary")) {
		dpURL = E1app;
	}
	if (dpEnv == "E2" && dpTier == "AppTier" && boxTyp == "Primary") {
		dpURL = E2AppPri;
	}
	if (dpEnv == "E2" && dpTier == "AppTier" && boxTyp == "Secondary") {
		dpURL = E2AppSec;
	}
	if (dpEnv == "E3" && dpTier == "AppTier" && boxTyp == "Primary") {
		dpURL = E3AppPri;
	}
	if (dpEnv == "E3" && dpTier == "AppTier" && boxTyp == "Secondary") {
		dpURL = E3AppSec;
	}
	
	if (dpEnv == "E1" && dpTier == "WebTier" && (boxTyp == "Primary" || boxTyp == "Secondary")) {
		dpURL = E1Web;
	}
	if (dpEnv == "E2" && dpTier == "WebTier" && boxTyp == "Primary") {
		dpURL = E2WebPri;
	}
	if (dpEnv == "E2" && dpTier == "WebTier" && boxTyp == "Secondary") {
		dpURL = E2WebSec;
	}
	if (dpEnv == "E3" && dpTier == "WebTier" && boxTyp == "Primary") {
		dpURL = E3WebPri;
	}
	if (dpEnv == "E3" && dpTier == "WebTier" && boxTyp == "Secondary") {
		dpURL = E3WebSec;
	}
	
	return dpURL;
	}
	
	

	}


