package ameriprise.DataPower.Utility;

import java.awt.EventQueue;

import javax.swing.JFrame;
import javax.swing.JPanel;
import javax.swing.border.EmptyBorder;
import javax.swing.JLabel;
import javax.swing.ButtonGroup;
import javax.swing.JButton;
import javax.swing.JComboBox;
import javax.swing.JRadioButton;
import javax.swing.JPasswordField;
import javax.swing.JTextArea;

public class LoginPage extends JFrame {

	public JPanel contentPane;
	public JPasswordField passwordField;

	/**
	 * Launch the application.
	 */
	public static void main(String[] args) {
		EventQueue.invokeLater(new Runnable() {
			public void run() {
				try {
					LoginPage frame = new LoginPage();
					frame.setVisible(true);
				} catch (Exception e) {
					e.printStackTrace();
				}
			}
		});
	}

	/**
	 * Create the frame.
	 */
	public LoginPage() {
		setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		setBounds(100, 100, 450, 300);
		contentPane = new JPanel();
		contentPane.setBorder(new EmptyBorder(5, 5, 5, 5));
		setContentPane(contentPane);
		contentPane.setLayout(null);
		
		JLabel lblNewLabel = new JLabel("Welcome to Data Power Utility");
		lblNewLabel.setBounds(113, 11, 211, 14);
		contentPane.add(lblNewLabel);
		
		JLabel lblNewLabel_1 = new JLabel("SSO ID");
		lblNewLabel_1.setBounds(37, 49, 46, 14);
		contentPane.add(lblNewLabel_1);
		
		JTextArea textArea = new JTextArea();
		textArea.setBounds(113, 44, 160, 22);
		contentPane.add(textArea);
		
		JLabel lblNewLabel_2 = new JLabel("Password");
		lblNewLabel_2.setBounds(37, 74, 46, 14);
		contentPane.add(lblNewLabel_2);
		
		passwordField = new JPasswordField();
		passwordField.setBounds(113, 71, 160, 20);
		contentPane.add(passwordField);
		
		
		JLabel lblNewLabel_4 = new JLabel("Tier");
		lblNewLabel_4.setBounds(37, 99, 46, 14); //
		contentPane.add(lblNewLabel_4);
		
		JRadioButton appTier = new JRadioButton("APP");
		appTier.setBounds(102, 95, 50, 23);
		appTier.setSelected(true);
		contentPane.add(appTier);
		
		JRadioButton webTier = new JRadioButton("WEB");
		webTier.setBounds(152, 95, 70, 23);
		webTier.setSelected(true);
		contentPane.add(webTier);
		
		ButtonGroup dpTier = new ButtonGroup();
		dpTier.add(appTier);
		dpTier.add(webTier);
		
		JLabel lblNewLabel_3 = new JLabel("DP Env");
		lblNewLabel_3.setBounds(37, 124, 46, 14); 
		contentPane.add(lblNewLabel_3);
		
		
		JRadioButton dpE1 = new JRadioButton("E1");
		dpE1.setBounds(102, 120, 40, 23);
		dpE1.setSelected(true);
		contentPane.add(dpE1);
		
		JRadioButton dpE2 = new JRadioButton("E2");
		dpE2.setBounds(152, 120, 40, 23);
		dpE2.setSelected(true);
		contentPane.add(dpE2);
		
		JRadioButton dpE3 = new JRadioButton("E3");
		dpE3.setBounds(202, 120, 40, 23);
		dpE3.setSelected(true);
		contentPane.add(dpE3);
		
		ButtonGroup dpEnvironment = new ButtonGroup();
		dpEnvironment.add(dpE1);
		dpEnvironment.add(dpE2);
		dpEnvironment.add(dpE3);

		//App
		//E1  E0Domain, E1Domain
		//E2  DudeDomain
		//E3  DudeDomain
		
		//Web
		//E1 E0WebDomain, E1WebDomain
		//E2   E1Domain,WebDomain
		//E3 WebDomain
		
		
		/*JLabel lblDomain = new JLabel("Domain");
		lblDomain.setBounds(37, 149, 46, 14);
		contentPane.add(lblDomain);
		
		JComboBox<String> comboLanguage = new JComboBox<String>();
		
		comboLanguage.addItem("E0Domain");
		comboLanguage.addItem("E1Domain");
		comboLanguage.addItem("DudeDomain");
		comboLanguage.addItem("E0WebDomain");
		comboLanguage.addItem("WebDomain");
		
		comboLanguage.setEditable(false);
		comboLanguage.setBounds(110, 149, 150, 23);*/
		
		
		/*// add items to the combo box
		// E1 App Tier
		if(dpE1.isSelected() && appTier.isSelected())
		{
			comboLanguage.addItem("E0Domain");
			comboLanguage.addItem("E1Domain");
			
			comboLanguage.setEditable(false);
			comboLanguage.setBounds(110, 149, 150, 23);
		}
		
		if((dpE2.isSelected() || dpE3.isSelected()) && appTier.isSelected())
		{
			comboLanguage.addItem("DudeDomain");
			
			comboLanguage.setEditable(false);
			comboLanguage.setBounds(110, 149, 150, 23);
		}
		
		
		contentPane.add(comboLanguage); */
		
		
		JButton btnLogin = new JButton("Login");
		btnLogin.setBounds(122, 192, 89, 23);
		contentPane.add(btnLogin);
		
		
		
	}
}
