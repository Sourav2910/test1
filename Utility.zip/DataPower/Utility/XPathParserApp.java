package ameriprise.DataPower.Utility;

import java.io.File;
import java.io.IOException;

import javax.xml.parsers.DocumentBuilderFactory;
import javax.xml.parsers.DocumentBuilder;
import javax.xml.parsers.ParserConfigurationException;
import javax.xml.xpath.XPath;
import javax.xml.xpath.XPathConstants;
import javax.xml.xpath.XPathExpressionException;
import javax.xml.xpath.XPathFactory;

import org.w3c.dom.Document;
import org.w3c.dom.NodeList;
import org.w3c.dom.Node;
import org.w3c.dom.Element;
import org.xml.sax.SAXException;

/**
 * 
 * @author ssingh140
 *
 */

public class XPathParserApp {

	private static Document getDocumentName() {
		File inputFile = null;
		DocumentBuilderFactory dbFactory = null;
		DocumentBuilder dBuilder = null;
		Document doc = null;
		try {
			inputFile = new File("C:/workspace/SOMAjavaVersion1/src/XPathParserDemo/input.xml");
			dbFactory = DocumentBuilderFactory.newInstance();
			dBuilder = dbFactory.newDocumentBuilder();
			doc = dBuilder.parse(inputFile);
			doc.getDocumentElement().normalize();
		} catch (ParserConfigurationException e1) {
			e1.printStackTrace();
		} catch (SAXException e2) {
			e2.printStackTrace();
		} catch (IOException e3) {
			e3.printStackTrace();
		}
		return doc;
	}

	private static boolean checkNullAndEmpty(String expValue) {
		if (null != expValue && expValue != "")
			return true;
		else
			return false;
	}

	private static String getService(String nodeName, String nodeValue) throws XPathExpressionException {
		String expression = null;
		XPath xPath = null;
		NodeList nodeList = null;
		Node nNode = null;

		if (checkNullAndEmpty(nodeName)) {
			expression = "/Envelope/Body/response/config/".concat(nodeName);
			xPath = XPathFactory.newInstance().newXPath();

			if (null != xPath && checkNullAndEmpty(expression)) {
				nodeList = (NodeList) xPath.compile(expression).evaluate(getDocumentName(), XPathConstants.NODESET);

				for (int i = 0; i < nodeList.getLength(); i++) {
					nNode = nodeList.item(i);
					if (nNode.getNodeType() == Node.ELEMENT_NODE) {
						Element eElement = (Element) nNode;

						if ("HTTPSSourceProtocolHandler".equalsIgnoreCase(nodeName)) {
							httpsNodeReader(nodeValue, eElement);
						}

						if ("SSLProxyProfile".equalsIgnoreCase(nodeName)) {
							sslProxyProfile(nodeValue, eElement);
						}

					}
				}
			}
		}
		return null;
	}

	private static String httpsNodeReader(String nodeValue, Element eElement) {
		String FSHname = null;
		String PortNumber = null;
		String PortStatus = null;
		String SSLProxyName = null;
		String SSLServerName = null;

		String IteratedPort = eElement.getElementsByTagName("LocalPort").item(0).getTextContent();
		if (checkNullAndEmpty(nodeValue) && IteratedPort.contains(nodeValue)) {
			FSHname = eElement.getAttribute("name");
			PortNumber = eElement.getElementsByTagName("LocalPort").item(0).getTextContent();
			PortStatus = eElement.getElementsByTagName("mAdminState").item(0).getTextContent();

			if (eElement.getElementsByTagName("SSLProxy").getLength() != 0) {
				SSLProxyName = eElement.getElementsByTagName("SSLProxy").item(0).getTextContent();
			} else {
				SSLServerName = eElement.getElementsByTagName("SSLServer").item(0).getTextContent();
			}

			System.out.println(FSHname);
			System.out.println(PortNumber);
			System.out.println(PortStatus);
			System.out.println(SSLProxyName.trim());
			System.out.println(SSLServerName);

			try {
				getService("SSLProxyProfile", SSLProxyName.trim());
			} catch (XPathExpressionException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}

		}
		return null;
	}

	private static String sslProxyProfile(String nodeValue, Element eElement) {
		String SSLstatus = null;
		String SSLdirection = null;
		String SSLForwardCryptoProfile = null;
		String SSLReverseCryptoProfile = null;

		String sslProxyProfileName = eElement.getAttribute("name");
		if (checkNullAndEmpty(sslProxyProfileName) && sslProxyProfileName.contains(nodeValue)) {
			SSLstatus = eElement.getElementsByTagName("mAdminState").item(0).getTextContent();
			SSLdirection = eElement.getElementsByTagName("Direction").item(0).getTextContent();
			if (eElement.getElementsByTagName("ForwardCryptoProfile").getLength() != 0) {
				SSLForwardCryptoProfile = eElement.getElementsByTagName("ForwardCryptoProfile").item(0)
						.getTextContent();
			}
			if (eElement.getElementsByTagName("ReverseCryptoProfile").getLength() != 0) {
				SSLReverseCryptoProfile = eElement.getElementsByTagName("ReverseCryptoProfile").item(0)
						.getTextContent();
			}

			System.out.println(SSLstatus);
			System.out.println(SSLdirection);
			System.out.println(SSLForwardCryptoProfile);
			System.out.println(SSLReverseCryptoProfile);

		}
		return null;
	}

	public static void main(String[] args) {
		try {
			getService("HTTPSSourceProtocolHandler", "59564");
		} catch (XPathExpressionException e) {
			e.printStackTrace();
		}
	}
}
