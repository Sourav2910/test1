package ameriprise.DataPower.Utility;

import java.awt.EventQueue;
import java.awt.TextField;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

import javax.swing.JFrame;
import javax.swing.JPanel;
import javax.swing.border.EmptyBorder;

import amaeriprise.DataPower.Cert_Upload_Backup.DP_Utility_Cert;

import javax.swing.JLabel;
import javax.swing.JOptionPane;
import javax.swing.ButtonGroup;
import javax.swing.JButton;
import javax.swing.JComboBox;
import javax.swing.JRadioButton;
import javax.swing.JPasswordField;
import javax.swing.JTextArea;
import javax.swing.JSeparator;

public class ExportImportServices_Swing extends JFrame implements ActionListener {

	public JPanel contentPane;
	public JPasswordField passwordField;
	
	public JTextArea ssoID,serviceNameText,saveLocationText;
	
	public JButton btnExport; 
	public ButtonGroup serviceType,dpEnvironment,tier,boxType;
	
	JComboBox<String> comboLanguage = new JComboBox<String>();
	
	TextField text = new TextField(20);
    private int numClicks = 0;

	/**
	 * Launch the application.
	 * @return 
	 */
  /*  public static void exportService()
    {
    	EventQueue.invokeLater(new Runnable() {
			public void run() {
				try {
					ExportServices frame = new ExportServices();
					frame.setVisible(true);
				} catch (Exception e) {
					e.printStackTrace();
				}
			}
		});
    }*/
    
	public static void main(String[] args) {
		EventQueue.invokeLater(new Runnable() {
			public void run() {
				try {
					ExportImportServices_Swing frame = new ExportImportServices_Swing();
					frame.setVisible(true);
				} catch (Exception e) {
					e.printStackTrace();
				}
			}
		});
	}

	/**
	 * Create the frame.
	 */
	public ExportImportServices_Swing() {
		setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		setBounds(100, 100, 890, 477);
		contentPane = new JPanel();
		contentPane.setBorder(new EmptyBorder(5, 5, 5, 5));
		setContentPane(contentPane);
		contentPane.setLayout(null);
		
		JLabel lblNewLabel = new JLabel("Welcome to Data Power Export and Import Service Utility");
		lblNewLabel.setBounds(205, 0, 459, 31);
		contentPane.add(lblNewLabel);
		
		JLabel lblNewLabel_1 = new JLabel("SSO ID");
		lblNewLabel_1.setBounds(205, 62, 60, 20);
		contentPane.add(lblNewLabel_1);
		
		ssoID = new JTextArea();
		ssoID.setBounds(296, 60, 227, 22);
		contentPane.add(ssoID);
		
		JLabel lblNewLabel_2 = new JLabel("Password");
		lblNewLabel_2.setBounds(205, 92, 60, 20);
		contentPane.add(lblNewLabel_2);
		
		passwordField = new JPasswordField();
		passwordField.setBounds(296, 92, 227, 20);
		contentPane.add(passwordField);
		
		
		JLabel lblNewLabel_4 = new JLabel("Service Type");
		lblNewLabel_4.setBounds(37, 273, 79, 14); //
		contentPane.add(lblNewLabel_4);
		
		JRadioButton wsp = new JRadioButton("WSP");
		wsp.setBounds(128, 269, 60, 23);
		wsp.setSelected(true);
		wsp.setActionCommand("WSGateway");
		contentPane.add(wsp);
		
		JRadioButton mpgw = new JRadioButton("MPGW");
		mpgw.setBounds(198, 269, 70, 23);
		mpgw.setSelected(true);
		mpgw.setActionCommand("MultiProtocolGateway");
		contentPane.add(mpgw);
		
		JRadioButton xmlfw = new JRadioButton("XMLFW");
		xmlfw.setBounds(268, 269, 70, 23);
		xmlfw.setSelected(true);
		xmlfw.setActionCommand("XMLFirewallService");
		contentPane.add(xmlfw);
		
		
		JRadioButton file = new JRadioButton("File");
		file.setBounds(412, 269, 52, 23);
		file.setSelected(true);
		file.setActionCommand("file");
		contentPane.add(file);
		
		
		JRadioButton service = new JRadioButton("Service");
		service.setBounds(614, 269, 79, 23);
		service.setSelected(true);
		service.setActionCommand("service");
		contentPane.add(service);
		
		
		JRadioButton domain = new JRadioButton("Domain");
		domain.setBounds(340, 269, 70, 23);
		domain.setSelected(true);
		domain.setActionCommand("domain");
		contentPane.add(domain);
		

		 serviceType = new ButtonGroup();
		serviceType.add(wsp);
		serviceType.add(mpgw);
		serviceType.add(xmlfw);
		serviceType.add(file);
		serviceType.add(domain);
		serviceType.add(service);
		
		JLabel lblNewLabel_3 = new JLabel("DP Env");
		lblNewLabel_3.setBounds(205, 123, 46, 14); 
		contentPane.add(lblNewLabel_3);
		
		JRadioButton dpE1 = new JRadioButton("E1");
		dpE1.setBounds(296, 119, 40, 23);
		dpE1.setSelected(true);
		dpE1.setActionCommand("E1");
		contentPane.add(dpE1);
		
		JRadioButton dpE2 = new JRadioButton("E2");
		dpE2.setBounds(361, 119, 40, 23);
		dpE2.setSelected(true);
		dpE2.setActionCommand("E2");
		contentPane.add(dpE2);
		
		JRadioButton dpE3 = new JRadioButton("E3");
		dpE3.setBounds(436, 119, 40, 23);
		dpE3.setSelected(true);
		dpE3.setActionCommand("E3");
		contentPane.add(dpE3);
		
		dpEnvironment = new ButtonGroup();
		dpEnvironment.add(dpE1);
		dpEnvironment.add(dpE2);
		dpEnvironment.add(dpE3);
		
		JRadioButton appTier = new JRadioButton("AppTier");
		appTier.setBounds(296, 145, 70, 23);
		appTier.setSelected(true);
		appTier.setActionCommand("AppTier");
		contentPane.add(appTier);
		
		JRadioButton webTier = new JRadioButton("WebTier");
		webTier.setBounds(366, 145, 89, 23);
		webTier.setSelected(true);
		webTier.setActionCommand("WebTier");
		contentPane.add(webTier);
		
		tier = new ButtonGroup();
		tier.add(appTier);
		tier.add(webTier);
		
		
		JLabel lblboxtyp = new JLabel("boxType");
		contentPane.add(lblboxtyp);
		
		JRadioButton primary = new JRadioButton("Primary");
		primary.setBounds(296, 171, 70, 23);
		primary.setSelected(true);
		primary.setActionCommand("Primary");
		contentPane.add(primary);
		
		JRadioButton secondary = new JRadioButton("Secondary");
		secondary.setBounds(366, 171, 110, 23);
		secondary.setSelected(true);
		secondary.setActionCommand("Secondary");
		contentPane.add(secondary);
		
		boxType = new ButtonGroup();
		boxType.add(primary);
		boxType.add(secondary);
		
		

		JLabel lblDomain = new JLabel("Domain");
		lblDomain.setBounds(205, 201, 46, 18);
		contentPane.add(lblDomain);
		
				
		comboLanguage.addItem("E0Domain");
		comboLanguage.addItem("E1Domain");
		comboLanguage.addItem("DudeDomain");
		comboLanguage.addItem("E1WebDomain");
		comboLanguage.addItem("WebDomain");
		
		comboLanguage.setEditable(false);
		comboLanguage.setBounds(306, 201, 149, 23);
		
		contentPane.add(comboLanguage);
		
		
		// Service/File Name
		
		JLabel serviceName = new JLabel("Service/File Name");
		serviceName.setBounds(37, 299, 106, 22);
		contentPane.add(serviceName);
		
		serviceNameText = new JTextArea();
		serviceNameText.setBounds(128, 298, 227, 22);
		contentPane.add(serviceNameText);
		
		
		
		JLabel savingLocation = new JLabel("Save As");
		savingLocation.setBounds(37, 361, 79, 20); 
		contentPane.add(savingLocation);
		
		saveLocationText = new JTextArea();
		saveLocationText.setBounds(128, 359, 229, 22);
		contentPane.add(saveLocationText);
		
		
		 btnExport = new JButton("Export");
		btnExport.setBounds(249, 405, 89, 23);
		contentPane.add(btnExport);
		btnExport.addActionListener(new ActionListener()
		{
		    public void actionPerformed(ActionEvent e)
		    {
		    	String loginID = ssoID.getText();
				String password = passwordField.getText();
				String serType= serviceType.getSelection().getActionCommand();
				String dpEnv = dpEnvironment.getSelection().getActionCommand();
				String dpTier = tier.getSelection().getActionCommand();
				String boxTyp = boxType.getSelection().getActionCommand();
				String domain = (String) comboLanguage.getSelectedItem();
				String serName = serviceNameText.getText();
				String saveAs = saveLocationText.getText();
				
				System.out.println(domain+serName+serType);
				
				
				DP_Utility dp_Utility = new DP_Utility();
				try {
					dp_Utility.exportFunction(loginID,password,serType,dpEnv,dpTier,boxTyp,domain,serName,saveAs);
				} catch (Exception e1) {
					// TODO Auto-generated catch block
					e1.printStackTrace();
				}
				
				System.out.println(domain+serName);
				
				JOptionPane.showMessageDialog(btnExport, "fileExported","title of dialog",2);
		        
		    }
		  		});
		
		
		
		JLabel lblTier = new JLabel("Tier");
		lblTier.setBounds(205, 148, 46, 14);
		contentPane.add(lblTier);
		
		JLabel lblBoxtype = new JLabel("BoxType");
		lblBoxtype.setBounds(205, 175, 46, 14);
		contentPane.add(lblBoxtype);
		
		JButton btnImport = new JButton("Import");
		btnImport.setBounds(658, 405, 89, 23);
		contentPane.add(btnImport);
		
		JLabel label = new JLabel("Service/File Name");
		label.setBounds(465, 332, 106, 22);
		contentPane.add(label);
		
		JTextArea textArea = new JTextArea();
		textArea.setBounds(566, 335, 219, 22);
		contentPane.add(textArea);
		
		JLabel lblBrowsepath = new JLabel("Browse Path");
		lblBrowsepath.setBounds(465, 301, 79, 20);
		contentPane.add(lblBrowsepath);
		
		JTextArea textArea_1 = new JTextArea();
		textArea_1.setBounds(564, 299, 219, 22);
		contentPane.add(textArea_1);
		
		JButton btnValidateExport = new JButton("Validate Export");
		btnValidateExport.setBounds(128, 405, 105, 23);
		contentPane.add(btnValidateExport);
		
		JButton btnValidateImport = new JButton("Validate Import");
		btnValidateImport.setBounds(543, 405, 105, 23);
		contentPane.add(btnValidateImport);
		
		JLabel lblSaveDirectory = new JLabel("Save Directory");
		lblSaveDirectory.setBounds(37, 332, 79, 20);
		contentPane.add(lblSaveDirectory);
		
		JTextArea textArea_2 = new JTextArea();
		textArea_2.setBounds(128, 332, 227, 22);
		contentPane.add(textArea_2);
		
		JButton btnNewButton = new JButton("Browse");
		btnNewButton.setBounds(354, 331, 89, 23);
		contentPane.add(btnNewButton);
		
		JButton button = new JButton("Browse");
		button.setBounds(785, 299, 89, 23);
		contentPane.add(button);
		
		JLabel label_1 = new JLabel("Service Type");
		label_1.setBounds(465, 273, 79, 19);
		contentPane.add(label_1);
		
		JRadioButton radioButton = new JRadioButton("File");
		radioButton.setSelected(true);
		radioButton.setActionCommand("file");
		radioButton.setBounds(560, 269, 52, 23);
		contentPane.add(radioButton);
		
		JLabel lblFunctionality = new JLabel("Functionality");
		lblFunctionality.setBounds(205, 230, 79, 14);
		contentPane.add(lblFunctionality);
		
		JRadioButton rdbtnImport = new JRadioButton("Import");
		rdbtnImport.setSelected(true);
		rdbtnImport.setActionCommand("AppTier");
		rdbtnImport.setBounds(296, 226, 70, 23);
		contentPane.add(rdbtnImport);
		
		JRadioButton rdbtnExport = new JRadioButton("Export");
		rdbtnExport.setSelected(true);
		rdbtnExport.setActionCommand("WebTier");
		rdbtnExport.setBounds(375, 226, 89, 23);
		contentPane.add(rdbtnExport);
		
		
		
		
		
		
		btnImport.addActionListener(new ActionListener()
		{
		    public void actionPerformed(ActionEvent e)
		    {
		        // Create a method named "createFrame()", and set up an new frame there
		    	
		    	String loginID = ssoID.getText().trim();
				String password = passwordField.getText().trim();
				String serType= serviceType.getSelection().getActionCommand();
				String dpEnv = dpEnvironment.getSelection().getActionCommand();
				String dpTier = tier.getSelection().getActionCommand();
				String boxTyp = boxType.getSelection().getActionCommand();
				String domain = (String) comboLanguage.getSelectedItem();
				String serName = serviceNameText.getText().trim();
				String saveAs = saveLocationText.getText().trim();
				
				System.out.println(domain+serName+serType);
				
				
				DP_Utility dp_Utility = new DP_Utility();
				try {
					dp_Utility.importFunction(loginID,password,serType,dpEnv,dpTier,boxTyp,domain,serName,saveAs);
				} catch (Exception e1) {
					// TODO Auto-generated catch block
					e1.printStackTrace();
				}
				
				System.out.println(domain+serName);
				
				JOptionPane.showMessageDialog(btnExport, "fileImported","title of dialog",2);
				
				
		     //    validateInformation(loginID,password,dpEnv,dpTier,dpTier,domain);
		    }
		});
		
		
		
		
	
	}

	@Override
	
	
	public void actionPerformed(ActionEvent e) {
	}
}
