package ameriprise.DataPower.Utility;

import javax.swing.JPanel;

public class Page1 extends JPanel {

	/**
	 * Create the panel.
	 */
	public Page1() {

	}

}
