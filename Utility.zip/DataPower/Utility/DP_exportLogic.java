package ameriprise.DataPower.Utility;

import java.io.IOException;
import java.io.StringReader;

import javax.xml.parsers.DocumentBuilder;
import javax.xml.parsers.DocumentBuilderFactory;
import javax.xml.parsers.ParserConfigurationException;

import org.w3c.dom.NodeList;
import org.xml.sax.InputSource;
import org.xml.sax.SAXException;
import org.w3c.dom.Document;

public class DP_exportLogic {
	
	
	public String exportFunction(String XML, String tag){
		
		// tag dp:file 
	
	 DocumentBuilderFactory factory = DocumentBuilderFactory.newInstance();
     DocumentBuilder builder;
     InputSource is;
     String exportedFile = "null";
     try {
         builder = factory.newDocumentBuilder();
         is = new InputSource(new StringReader(XML));
         Document doc = builder.parse(is);
         NodeList list = doc.getElementsByTagName(tag);
        /* System.out.println(list.item(0).getTextContent());*/
         exportedFile  = list.item(0).getTextContent();
     } catch (ParserConfigurationException e) {
     } catch (SAXException e) {
     } catch (IOException e) {
     }
     return exportedFile;
     
	}

}
