package ameriprise.DataPower.Utility;

public class Test {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		
		String domain = "domain";
		String servNam = "servNam";
		String servTyp = "servTyp";
		
		String s="<soapenv:Envelope xmlns:soapenv=" + '"' + "http://schemas.xmlsoap.org/soap/envelope/" + '"'
				+ "xmlns:man=" + '"' + "http://www.datapower.com/schemas/management" + '"' + ">"
				+ "<soapenv:Header/><soapenv:Body><man:request domain=" + '"' + domain + '"' + ">"
				+ "<man:do-export format=" + '"' + "ZIP" + '"' + ">" + "<man:object class=" + '"' + servTyp + '"'
				+ " name=" + '"' + servNam + '"' + " ref-objects=" + '"' + "true" + '"' + "ref-files=" + '"' + "true"
				+ '"' + "/>" + "</man:do-export></man:request></soapenv:Body></soapenv:Envelope>";   
		   System.out.println(s);   

	}

}
