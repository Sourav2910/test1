package ameriprise.DataPower.Utility;

public class Snippet {
	public static void main(String[] args) {
		EWF_Aggregator_NotificationService_JSON_MPGW
	}
}

