package ameriprise.DataPower.XMLmanagerUpdate;

import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.io.FileWriter;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.Iterator;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;
import java.util.Set;
import java.util.Map.Entry;

import org.jaxen.function.NormalizeSpaceFunction;

public class DP_Utility {

	public static void main(String[] args) {
		String E1app = "https://159.202.100.92:5550/service/mgmt/2004";
		String E2AppPri = "https://159.202.100.94:5550/service/mgmt/2004";
		String E2AppSec = "https://159.202.100.96:5550/service/mgmt/2004";
		String E3AppPri = "https://159.202.252.73:5550/service/mgmt/2004";
		String E3AppSec = "https://159.202.252.74:5550/service/mgmt/2004";

		// input Parameters

		String dpURL = "https://159.202.100.92:5550/service/mgmt/2004";
		String loginID = "ssingh140";
		String password = "Mar@2018";
		String domain = "E0Domain";
		String ServiceType = "WSGateway";
		String ServiceName = "Sql_Metrics_MPGW";

		// WSGateway
		// XMLFirewallService
		// MultiProtocolGateway

		// create MAP object to store XMLmanaer details
		Map<String, String> MPGWHash_response_fetch = new LinkedHashMap<String, String>();

		// invoking DP for fetch Details
		String responseDPfetch = invokeDP(dpURL, loginID, password, domain, ServiceType, "fetch", "", "", "");

		MPGWHash_response_fetch = DOMparser(responseDPfetch, ServiceType);

		System.out.println(MPGWHash_response_fetch);

		// String responseDP_update =
		// invokeDP(dpURL,loginID,password,domain,ServiceType,"update","AAH_Aggregate_XMLFW");

		// convert input to EXCEL and store that
		// CovertHash2EXCEL_write(MPGWHash_response_fetch);

		Set<Map.Entry<String, String>> st = MPGWHash_response_fetch.entrySet();

		if (ServiceType.equalsIgnoreCase("XMLFirewallService")) {
			for (Entry<String, String> me : st) {
				String XMLmngrNameandXMLfwPort[] = me.getValue().split(":");
				String XMLmngrName = XMLmngrNameandXMLfwPort[0];
				String XMLfwLocalAddress = XMLmngrNameandXMLfwPort[1];
				String XMLfwPort = XMLmngrNameandXMLfwPort[2];

				System.out.println(XMLmngrName + ":" + XMLfwLocalAddress + ":" + XMLfwPort);

				if (XMLmngrName.equalsIgnoreCase("default")) {

					// String responseDP_create_XMLMNGR =
					// invokeDP(dpURL,loginID,password,domain,ServiceType,"create",me.getKey());
					String responseDP_update = invokeDP(dpURL, loginID, password, domain, ServiceType, "updateXMLFW",
							me.getKey(), XMLfwLocalAddress, XMLfwPort);

					System.out.print(me.getKey() + ":");
					// System.out.println(me.getValue());

					System.out.print(XMLmngrName + ":");
					System.out.println(XMLfwPort);

					// System.out.println(responseDP_create_XMLMNGR+":");
					// System.out.println(responseDP_update);

				}

			}
		} else {

			for (Entry<String, String> me : st) {

				if (!me.getValue().equalsIgnoreCase("default")) {

					/*
					 * String responseDP_create_XMLMNGR =
					 * invokeDP(dpURL,loginID,password,domain,ServiceType,
					 * "create",me.getKey()); String responseDP_update =
					 * invokeDP(dpURL,loginID,password,domain,ServiceType,
					 * "update",me.getKey());
					 */
					System.out.print(me.getKey() + ":");
					System.out.println(me.getValue());
					/*
					 * System.out.println(responseDP_create_XMLMNGR+":");
					 * System.out.println(responseDP_update);
					 */

				}

			}

		}

		// String responseDP_create_XMLMNGR =
		// invokeDP(dpURL,loginID,password,domain,ServiceType,"create",ServiceName);

		// String responseDP_update =
		// invokeDP(dpURL,loginID,password,domain,ServiceType,"update",ServiceName);

		// System.out.println(responseDPfetch);
		// System.out.println(responseDP_create_XMLMNGR);
		// System.out.println(responseDP_update);

		// System.out.println("responseDomParser::"+ responseDomParser);

	}

	public static String invokeDP(String dpURL, String loginID, String password, String domain, String ServiceType,
			String FetchOrUpdate, String ServiceName, String XMLFwLocalAddress, String XMLfwPort) {
		String inputXML = null;

		if (FetchOrUpdate.equalsIgnoreCase("fetch")) {
			inputXML = generateInputXmltoFetchXMLmngrDetails(domain, ServiceType);
		}

		if (FetchOrUpdate.equalsIgnoreCase("create")) {
			inputXML = generateInputXmltoCreateXMLmngr(domain, ServiceType, ServiceName);
		}

		if (FetchOrUpdate.equalsIgnoreCase("update")) {
			inputXML = generateInputXmltoUpdateXMLmngrDetails(domain, ServiceType, ServiceName);
		}

		if (FetchOrUpdate.equalsIgnoreCase("updateXMLFW")) {
			inputXML = generateInputXmltoUpdateXMLmngrDetailsForXMLFWL(domain, ServiceType, ServiceName,
					XMLFwLocalAddress, XMLfwPort);
		}

		String response = null;
		CallDataPower callDataPower = new CallDataPower();
		try {
			response = callDataPower.callDP(dpURL, inputXML, loginID, password);
		} catch (Exception e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}

		return response;
	}

	public static Map<String, String> DOMparser(String responseDP, String ServiceType) {

		Map<String, String> MPGWHash_response = null;

		Call_DomParser call_DomParser = new Call_DomParser();
		try {
			MPGWHash_response = call_DomParser.DomParser(responseDP, ServiceType);
		} catch (Exception e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}

		return MPGWHash_response;
	}

	public static String CovertHash2EXCEL_write(HashMap<String, String> hashMap) {

		String response = null;

		CovertHash2EXCEL covertHash2EXCEL = new CovertHash2EXCEL();
		try {
			response = covertHash2EXCEL.CovertHash2EXCEL_write(hashMap);
		} catch (Exception e) {
			e.printStackTrace();
		}

		return response;
	}

	/*
	 * public void exportFunction(String loginID, String password, String
	 * serType, String dpEnv, String dpTier, String boxTyp, String domain,
	 * String serName, String saveAs) throws Exception { String dpURL = null;
	 * 
	 * if (dpEnv == "E1" && dpTier == "AppTier" && (boxTyp == "Primary" ||
	 * boxTyp == "Secondary")) { dpURL = E1app; } if (dpEnv == "E2" && dpTier ==
	 * "AppTier" && boxTyp == "Primary") { dpURL = E2AppPri; } if (dpEnv == "E2"
	 * && dpTier == "AppTier" && boxTyp == "Secondary") { dpURL = E2AppSec; } if
	 * (dpEnv == "E3" && dpTier == "AppTier" && boxTyp == "Primary") { dpURL =
	 * E3AppPri; } if (dpEnv == "E3" && dpTier == "AppTier" && boxTyp ==
	 * "Secondary") { dpURL = E3AppSec; }
	 * 
	 * String inputXML = generateInputXml(domain, serType, serName);
	 * 
	 * callDataPower.callDP(dpURL, inputXML, loginID, password, serName,domain);
	 * }
	 */

	public static String generateInputXmltoFetchXMLmngrDetails(String domain, String serviceType) {

		/*
		 * String inputXML=
		 * "C:/Tool/DataPower_Utility_Application/src/ameriprise/DataPower/Utility/SomaRequest.xml";
		 */

		String inputXML = "<soapenv:Envelope xmlns:soapenv=" + '"' + "http://schemas.xmlsoap.org/soap/envelope/" + '"'
				+ " xmlns:man=" + '"' + "http://www.datapower.com/schemas/management" + '"' + ">"
				+ "<soapenv:Header/><soapenv:Body><man:request domain=" + '"' + domain + '"' + ">"
				+ "<man:get-config class=" + '"' + serviceType + '"' + "/>"
				+ "</man:request></soapenv:Body></soapenv:Envelope>";

		try {
			FileWriter fw = new FileWriter(
					"C:/Tool/DataPower_Utility_Application/src/ameriprise/DataPower/Utility/SomaRequest_XMLmanager_fetch.xml",
					true);
			fw.write(inputXML);
			fw.close();
		} catch (Exception e) {
			System.out.println(e);
		}
		System.out.println("Success...SomaRequest_XMLmanager_fetch.xml generated");

		String inputXMLFile = "C:/Tool/DataPower_Utility_Application/src/ameriprise/DataPower/Utility/SomaRequest_XMLmanager_fetch.xml";

		return inputXML;
	}

	public static String generateInputXmltoUpdateXMLmngrDetailsForXMLFWL(String domain, String serviceType,
			String serviceName, String LocalAddress, String LocalPort) {

		/*
		 * String inputXML=
		 * "C:/Tool/DataPower_Utility_Application/src/ameriprise/DataPower/Utility/SomaRequest.xml";
		 */

		String inputXML = "<soapenv:Envelope xmlns:soapenv=" + '"' + "http://schemas.xmlsoap.org/soap/envelope/" + '"'
				+ " xmlns:man=" + '"' + "http://www.datapower.com/schemas/management" + '"' + ">"
				+ "<soapenv:Header/><soapenv:Body>" + "<man:request domain=" + '"' + domain + '"' + ">"
				+ "<man:set-config>" + "<" + serviceType.trim() + " name=" + '"' + serviceName.trim() + '"' + ">"
				+ "<LocalAddress>" + LocalAddress + "</LocalAddress>" + "<LocalPort>" + LocalPort + "</LocalPort>"
				+ "<XMLManager class=" + '"' + "XMLManager" + '"' + ">" + serviceName.trim() + "_XMLMNG"
				+ "</XMLManager>" + "</" + serviceType.trim() + ">" + "</man:set-config>"
				+ "</man:request></soapenv:Body></soapenv:Envelope>";

		/*
		 * <man:set-config> <WSGateway name="E0Test_WSP">
		 * 
		 * <XMLManager class="XMLManager">test_XMLmanager</XMLManager>
		 * </WSGateway>
		 */

		try {
			FileWriter fw = new FileWriter(
					"C:/Tool/DataPower_Utility_Application/src/ameriprise/DataPower/Utility/SomaRequest_XMLmanager_XMLFW_Update.xml",
					true);
			fw.write(inputXML);
			fw.close();
		} catch (Exception e) {
			System.out.println(e);
		}
		System.out.println("Success...SomaRequest_XMLmanager_Update.xml generated");

		String inputXMLFile = "C:/Tool/DataPower_Utility_Application/src/ameriprise/DataPower/Utility/SomaRequest_XMLmanager_XMLFW_Update.xml.xml";
		return inputXML;
	}

	public static String generateInputXmltoUpdateXMLmngrDetails(String domain, String serviceType, String serviceName) {

		/*
		 * String inputXML=
		 * "C:/Tool/DataPower_Utility_Application/src/ameriprise/DataPower/Utility/SomaRequest.xml";
		 */

		String inputXML = "<soapenv:Envelope xmlns:soapenv=" + '"' + "http://schemas.xmlsoap.org/soap/envelope/" + '"'
				+ " xmlns:man=" + '"' + "http://www.datapower.com/schemas/management" + '"' + ">"
				+ "<soapenv:Header/><soapenv:Body>" + "<man:request domain=" + '"' + domain + '"' + ">"
				+ "<man:set-config>" + "<" + serviceType.trim() + " name=" + '"' + serviceName.trim() + '"' + ">"
				+ "<XMLManager class=" + '"' + "XMLManager" + '"' + ">" + serviceName.trim() + "_XMLMNG"
				+ "</XMLManager>" + "</" + serviceType.trim() + ">" + "</man:set-config>"
				+ "</man:request></soapenv:Body></soapenv:Envelope>";

		try {
			FileWriter fw = new FileWriter(
					"C:/Tool/DataPower_Utility_Application/src/ameriprise/DataPower/Utility/SomaRequest_XMLmanager_Update.xml",
					true);
			fw.write(inputXML);
			fw.close();
		} catch (Exception e) {
			System.out.println(e);
		}
		System.out.println("Success...SomaRequest_XMLmanager_Update.xml generated");

		String inputXMLFile = "C:/Tool/DataPower_Utility_Application/src/ameriprise/DataPower/Utility/SomaRequest_XMLmanager_Update.xml";
		return inputXML;
	}

	public static String generateInputXmltoCreateXMLmngr(String domain, String serviceType, String serviceName) {

		/*
		 * String inputXML=
		 * "C:/Tool/DataPower_Utility_Application/src/ameriprise/DataPower/Utility/SomaRequest.xml";
		 */

		String inputXML = "<soapenv:Envelope xmlns:soapenv=" + '"' + "http://schemas.xmlsoap.org/soap/envelope/" + '"'
				+ " xmlns:man=" + '"' + "http://www.datapower.com/schemas/management" + '"' + ">"
				+ "<soapenv:Header/><soapenv:Body>" + "<man:request domain=" + '"' + domain + '"' + ">"
				+ "<man:set-config>"

				+ "<XMLManager" + " name=" + '"' + serviceName.trim() + "_XMLMNG" + '"' + ">"
				+ "<mAdminState>enabled</mAdminState><UserSummary>Default XML-Manager</UserSummary><CacheSize>256</CacheSize><SHA1Caching>on</SHA1Caching><StaticDocumentCalls>on</StaticDocumentCalls><SearchResults>on</SearchResults><SupportTxWarn>off</SupportTxWarn><ParserLimitsBytesScanned>4194304</ParserLimitsBytesScanned><ParserLimitsElementDepth>512</ParserLimitsElementDepth><ParserLimitsAttributeCount>128</ParserLimitsAttributeCount><ParserLimitsMaxNodeSize>33554432</ParserLimitsMaxNodeSize><ParserLimitsForbidExternalReferences>on</ParserLimitsForbidExternalReferences><ParserLimitsExternalReferences>forbid</ParserLimitsExternalReferences><ParserLimitsMaxPrefixes>1024</ParserLimitsMaxPrefixes><ParserLimitsMaxNamespaces>1024</ParserLimitsMaxNamespaces><ParserLimitsMaxLocalNames>60000</ParserLimitsMaxLocalNames><DocCacheMaxDocs>5000</DocCacheMaxDocs><DocCacheSize>0</DocCacheSize><DocMaxWrites>32768</DocMaxWrites>"
				+ "<UserAgent class=" + '"' + "HTTPUserAgent" + '"' + ">" + "default" + "</UserAgent>" + "</XMLManager>"

				+ "</man:set-config>" + "</man:request></soapenv:Body></soapenv:Envelope>";

		try {
			FileWriter fw = new FileWriter(
					"C:/Tool/DataPower_Utility_Application/src/ameriprise/DataPower/Utility/SomaRequest_XMLmanager_Create.xml",
					true);
			fw.write(inputXML);
			fw.close();
		} catch (Exception e) {
			System.out.println(e);
		}
		System.out.println("Success...SomaRequest_XMLmanager_Create.xml generated");

		String inputXMLFile = "C:/Tool/DataPower_Utility_Application/src/ameriprise/DataPower/Utility/SomaRequest_XMLmanager_Create.xml";
		return inputXML;
	}

}
