package ameriprise.DataPower.XMLmanagerUpdate;

import java.io.File;
import java.io.IOException;
import java.io.StringReader;

import javax.xml.parsers.DocumentBuilder;
import javax.xml.parsers.DocumentBuilderFactory;
import javax.xml.parsers.ParserConfigurationException;

import org.w3c.dom.NodeList;
import org.xml.sax.InputSource;
import org.xml.sax.SAXException;

import com.itextpdf.text.Element;

import org.w3c.dom.Document;
import org.w3c.dom.NamedNodeMap;
import java.util.*;
import java.util.Map.Entry;

public class Call_DomParser {
	
	
	public Map<String, String> DomParser(String input, String ServiceType){
		
	
	 DocumentBuilderFactory factory = DocumentBuilderFactory.newInstance();
     DocumentBuilder builder;
     InputSource is;
     String firstMPGW = null;
     String firstWSP = null;
     String firstXMLFW = null;
     
     Map<String, String> map = new LinkedHashMap<String, String>();
     try {
         
    	 // document Builder
    	 builder = factory.newDocumentBuilder();
         is = new InputSource(new StringReader(input));
         Document doc = builder.parse(is);
         
         /*NodeList XMLFW = doc.getElementsByTagName("XMLFirewallService");
         firstXMLFW =XMLFW.item(0).getAttributes().getNamedItem("name").getNodeValue();
       
         NodeList WSP = doc.getElementsByTagName("WSGateway");
         firstWSP =WSP.item(0).getAttributes().getNamedItem("name").getNodeValue();*/
         
         NodeList ServiceNodeList = doc.getElementsByTagName(ServiceType);
         
         
     
         // retrieving service name and corresponding XMLMngr
        
         int i = 0;
         int j = 0;
         
         if (ServiceType.equalsIgnoreCase("XMLFirewallService"))
         {
        	 
        	 for(i=0; i< ServiceNodeList.getLength(); i++)
             {
            	 
            	 String Servicename = ServiceNodeList.item(i).getAttributes().getNamedItem("name").getNodeValue();
            	 
            	// System.out.println("Name of "+i+ " MPGW is :: " + MPGWname);
            	
            	 NodeList ServiceNodeList_child = ServiceNodeList.item(i).getChildNodes();
            	 
            	 String XMLmngrName = null;
            	 String XMLfwPort = null;
            	 String XMLfwLocalAddress = null;
            	 for(j=0; j< ServiceNodeList_child.getLength(); j++)
            	 {
            		 if(ServiceNodeList_child.item(j).getNodeName().equalsIgnoreCase("XMLManager") || ServiceNodeList_child.item(j).getNodeName().equalsIgnoreCase("LocalPort")
            				 || ServiceNodeList_child.item(j).getNodeName().equalsIgnoreCase("LocalAddress") )
            		 {
            			 
            			// System.out.println("Name of XMLMANGER is :: " + XMLmngrName); 
            			 
            			 if(ServiceNodeList_child.item(j).getNodeName().equalsIgnoreCase("XMLManager"))
            			 {
            				 XMLmngrName = ServiceNodeList_child.item(j).getTextContent();
            			 }
            			 if(ServiceNodeList_child.item(j).getNodeName().equalsIgnoreCase("LocalPort"))
            			 {
            				 XMLfwPort = ServiceNodeList_child.item(j).getTextContent();
            			 }
            			 if(ServiceNodeList_child.item(j).getNodeName().equalsIgnoreCase("LocalAddress"))
            			 {
            				 XMLfwLocalAddress = ServiceNodeList_child.item(j).getTextContent();
            			 }
            			
            		 }
            		 
            		 
            	 }
            	 
            	 map.put(Servicename,XMLmngrName+":"+XMLfwLocalAddress+":"+XMLfwPort);
             } 
        	 
         
         }
         else
         {
        	 
             for(i=0; i< ServiceNodeList.getLength(); i++)
             {
            	 
            	 String Servicename = ServiceNodeList.item(i).getAttributes().getNamedItem("name").getNodeValue();
            	 
            	// System.out.println("Name of "+i+ " MPGW is :: " + MPGWname);
            	
            	 NodeList ServiceNodeList_child = ServiceNodeList.item(i).getChildNodes();
            	 
            	 for(j=0; j< ServiceNodeList_child.getLength(); j++)
            	 {
            		 if(ServiceNodeList_child.item(j).getNodeName().equals("XMLManager"))
            		 {
            			 String XMLmngrName = ServiceNodeList_child.item(j).getTextContent();
            			// System.out.println("Name of XMLMANGER is :: " + XMLmngrName); 
            			 
            			 map.put(Servicename,XMLmngrName);
            		 }
            		 
            		 
            	 }
             }
         }
         
         
        /* System.out.println(list.item(0).getTextContent());*/
         /*firstMPGW  = list.item(0).getTextContent();*/
         
     } catch (ParserConfigurationException e) {
     } catch (SAXException e) {
     } catch (IOException e) {
     }
     
     
     return map;
     
	}
	
	
	

}
