package ameriprise.DataPower.XMLmanagerUpdate;
import java.io.BufferedReader;
import java.io.File;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.FileReader;
import java.io.IOException;
import java.text.SimpleDateFormat;
import java.util.Date;

import org.apache.poi.hssf.usermodel.HSSFCell;
import org.apache.poi.hssf.usermodel.HSSFRow;
import org.apache.poi.hssf.usermodel.HSSFSheet;
import org.apache.poi.hssf.usermodel.HSSFWorkbook;

public class CovertHash2EXCEL_backup {

	  public static void main(String[] args) throws IOException 
	  {
		  
		  String excelFileName = "C:/Users/ssingh140/Desktop/DataPowerExport/sourabh_XMLmanager.xls";//name of excel file

			String sheetName = "MPGW";//name of sheet

			HSSFWorkbook wb = new HSSFWorkbook();
			HSSFSheet sheet = wb.createSheet(sheetName) ;

			//iterating r number of rows
			for (int r=0;r < 5; r++ )
			{
				HSSFRow row = sheet.createRow(r);
		
				//iterating c number of columns
				for (int c=0;c < 5; c++ )
				{
					HSSFCell cell = row.createCell(c);
					
					cell.setCellValue("Cell "+r+" "+c);
				}
			}
			
			/*FileOutputStream fileOut = new FileOutputStream(excelFileName);*/
			
				/*Date d1 = new Date();
	            SimpleDateFormat sdf = new SimpleDateFormat("dd-MMM-yy");
	            String todaysDate = sdf.format(d1);
	            System.out.println(sdf.format(d1));*/
	            
	            
	            //Create file system using specific name
	            FileOutputStream fileOut = new FileOutputStream(new File(excelFileName));
			
			
			//write this workbook to an Outputstream.
				wb.write(fileOut);
				fileOut.flush();
				fileOut.close();
		  
	    /* BufferedReader br = null;

	     try {

	        br = new BufferedReader(new FileReader(new File("C:/Tool/DataPower_Utility_Application/src/ameriprise/DataPower/Cert_Monitoring/InputHTML.html")));

	        // Create Work book
	          XSSFWorkbook xwork = new XSSFWorkbook();

	          // Create Spread Sheet
	          XSSFSheet xsheet = xwork.createSheet("CertE0");

	          //Create Row (Row is inside spread sheet)
	          XSSFRow xrow  = null;

	          int rowid =0;
	          String line ;
	          while (( line =br.readLine())!= null) {



	            // Create font for applying bold or italic or same thing else on the content
	            XSSFFont xfont = xwork.createFont();
	            xfont.setBoldweight(xfont.BOLDWEIGHT_BOLD);

	            XSSFCellStyle xstyle = xwork.createCellStyle();
	            xstyle.setFont(xfont);

	             System.out.println(line);

	             String split[] = line.split("<br>");
	             Cell cell;
	             for (int i = 0; i < split.length; i++) {
	                 xrow = xsheet.createRow(rowid);
	                 cell = xrow.createCell(2);
	                 cell.setCellValue(split[i]);
	                 String[] columnSplit = split[i].split("\\W+");
	                 int columnCount = 3;
	                 for (int j = 0; j < columnSplit.length; j++) {

	                     cell = xrow.createCell(columnCount++);
	                     cell.setCellValue(columnSplit[j]);
	                }
	                System.out.println(split[i]);
	                rowid++;
	            }

	          } 


	        // create date for adding this to our workbook name like workbookname_date
	            Date d1 = new Date();
	            SimpleDateFormat sdf = new SimpleDateFormat("dd-MMM-yy");
	            String todaysDate = sdf.format(d1);
	            System.out.println(sdf.format(d1));
	            //Create file system using specific name
	            FileOutputStream fout = new FileOutputStream(new File("C:/Tool/DataPower_Utility_Application/src/ameriprise/DataPower/Cert_Monitoring/InputHTML.html_"+todaysDate+".xlsx"));

	            xwork.write(fout);
	            fout.close();
	            System.out.println("redaingfromHTMLFile_"+todaysDate+".xlsx written successfully" );
	     }
	     catch (Exception e) {
	        e.printStackTrace();
	    }*/
	  }
	}
	
	
	
	

